const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProjectPayload(uid, now) {
  return {
    userId: uid,
    name: "Portfolio Studio",
    summary: "Responsive portfolio website with interactive contact form.",
    appType: "WEBSITE",
    promptLanguage: "AUTO",
    lastPrompt: "Build a sleek portfolio website with dark glassmorphism",
    techStack: ["HTML5", "CSS3", "JavaScript"],
    primaryColorHex: "#8B5CF6",
    accentColorHex: "#38BDF8",
    deploymentGuide: "Upload ZIP to Netlify Drop or Cloudflare Pages.",
    previewHtml: "<!DOCTYPE html><html><body><h1>Portfolio</h1></body></html>",
    fileCount: 3,
    version: 1,
    settingsIncludeBackend: false,
    settingsResponsive: true,
    settingsDarkTheme: true,
    publishStatus: "DRAFT",
    createdAt: now,
    updatedAt: now,
  };
}

test("Unauthenticated user cannot read or write projects, files, or history", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = new Date(Date.now() - 1000);

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").set(validProjectPayload(ALICE_UID, now))
  );
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("promptHistory").get());
});

test("Owner can create, list, partially update, publish, and delete project + batch files + history", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 5000);
  const projectRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1");
  const fileRef = projectRef.collection("files").doc("file_0");
  const historyRef = aliceDb.collection("users").doc(ALICE_UID).collection("promptHistory").doc("hist_1");

  const batch = aliceDb.batch();
  batch.set(projectRef, validProjectPayload(ALICE_UID, created));
  batch.set(fileRef, {
    userId: ALICE_UID,
    projectId: "proj_1",
    path: "index.html",
    language: "html",
    content: "<!DOCTYPE html><html></html>",
    createdAt: created,
    updatedAt: created,
  });
  batch.set(historyRef, {
    userId: ALICE_UID,
    projectId: "proj_1",
    projectName: "Portfolio Studio",
    prompt: "Build a sleek portfolio website",
    actionType: "GENERATE",
    imageCount: 1,
    summary: "Generated initial website",
    version: 1,
    createdAt: created,
  });

  await assertSucceeds(batch.commit());

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertSucceeds(projectRef.collection("files").get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("promptHistory").get());

  // Partial update on project + publishStatus transition
  await assertSucceeds(
    projectRef.update({
      lastPrompt: "Change colors to emerald",
      primaryColorHex: "#10B981",
      version: 2,
      publishStatus: "PUBLISHED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject invalid publishStatus enum
  await assertFails(
    projectRef.update({
      publishStatus: "INVALID_STATUS",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject immutable createdAt modification
  await assertFails(
    projectRef.update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject ghost field on create ("Shadow Update Test")
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_ghost").set({
      ...validProjectPayload(ALICE_UID, created),
      id: "proj_ghost",
    })
  );

  // Reject future timestamp
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_future").set(
      validProjectPayload(ALICE_UID, new Date(Date.now() + 60000))
    )
  );
});

test("Cross-user isolation: Bob cannot read, update, or delete Alice's projects, files, or history", async () => {
  const created = new Date(Date.now() - 10000);
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").set(validProjectPayload(ALICE_UID, created));
    await db.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").collection("files").doc("file_0").set({
      userId: ALICE_UID,
      projectId: "proj_1",
      path: "index.html",
      language: "html",
      content: "<h1>Alice</h1>",
      createdAt: created,
      updatedAt: created,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").update({ name: "Hijacked" }));
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").delete());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").collection("files").get());
});
