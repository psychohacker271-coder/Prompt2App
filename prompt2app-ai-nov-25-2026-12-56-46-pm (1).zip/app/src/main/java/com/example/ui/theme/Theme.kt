package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp

private val Prompt2AppDarkColorScheme = darkColorScheme(
    primary = ElectricViolet,
    onPrimary = TextPrimary,
    primaryContainer = DeepIndigoContainer,
    onPrimaryContainer = ElectricVioletLight,
    secondary = CyberCyan,
    onSecondary = ObsidianBg,
    secondaryContainer = ColorTokens.SecondaryContainer,
    onSecondaryContainer = CyberCyan,
    tertiary = EmeraldMint,
    onTertiary = ObsidianBg,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = EmeraldMint,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = ObsidianBg,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianCard,
    surfaceContainerHigh = ObsidianCardElevated,
    outline = GlassBorder,
    outlineVariant = GlassBorderStrong,
    error = RoseCoral,
    onError = TextPrimary,
    errorContainer = RoseContainer,
    onErrorContainer = RoseCoral
)

private object ColorTokens {
    val SecondaryContainer = androidx.compose.ui.graphics.Color(0xFF0E2C47)
}

val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

object StudioBrushes {
    val primaryGradient = Brush.linearGradient(
        colors = listOf(ElectricViolet, NeonIndigo, CyberCyan)
    )
    val subtleSurfaceGradient = Brush.verticalGradient(
        colors = listOf(ObsidianCardElevated.copy(alpha = 0.85f), ObsidianCard.copy(alpha = 0.92f))
    )
    val ambientBackdrop = Brush.radialGradient(
        colors = listOf(
            ElectricViolet.copy(alpha = 0.18f),
            CyberCyan.copy(alpha = 0.08f),
            ObsidianBg
        )
    )
}

@Composable
fun Prompt2AppTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = Prompt2AppDarkColorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
