package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.FolderCopy
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.model.BuilderTab
import com.example.ui.screens.CodeExportScreen
import com.example.ui.screens.PreviewScreen
import com.example.ui.screens.ProjectsDashboardScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepIndigoContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.StudioBrushes
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BuilderViewModel

@Composable
fun Prompt2AppRoot(
    viewModel: BuilderViewModel
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: BuilderTab.STUDIO.route

    val projectsState by viewModel.projectsState.collectAsStateWithLifecycle()
    val historyState by viewModel.promptHistoryState.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()
    val activeFiles by viewModel.activeProjectFiles.collectAsStateWithLifecycle()

    val promptText by viewModel.promptText.collectAsStateWithLifecycle()
    val appType by viewModel.appType.collectAsStateWithLifecycle()
    val promptLanguage by viewModel.promptLanguage.collectAsStateWithLifecycle()
    val attachments by viewModel.attachments.collectAsStateWithLifecycle()
    val settingsDraft by viewModel.settingsDraft.collectAsStateWithLifecycle()
    val generationState by viewModel.generationState.collectAsStateWithLifecycle()
    val agentSteps by viewModel.agentSteps.collectAsStateWithLifecycle()
    val copilotPhase by viewModel.copilotPhase.collectAsStateWithLifecycle()
    val previewDevice by viewModel.previewDevice.collectAsStateWithLifecycle()
    val aiEditInstruction by viewModel.aiEditInstruction.collectAsStateWithLifecycle()
    val consoleLogs by viewModel.consoleLogs.collectAsStateWithLifecycle()
    val reloadNonce by viewModel.previewReloadNonce.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToastMessage()
        }
    }

    fun navigateToTab(tab: BuilderTab) {
        navController.navigate(tab.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .background(StudioBrushes.ambientBackdrop)
    ) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                StudioTopBar(activeProjectName = activeProject?.name)
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = ObsidianSurface.copy(alpha = 0.96f),
                        windowInsets = WindowInsets.navigationBars,
                        tonalElevation = 0.dp
                    ) {
                        BuilderTab.entries.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, selected),
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = DeepIndigoContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = ObsidianSurface.copy(alpha = 0.94f),
                        modifier = Modifier
                            .fillMaxHeight()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        Spacer(Modifier.size(12.dp))
                        BuilderTab.entries.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, selected),
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = DeepIndigoContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("rail_tab_${tab.route}")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = BuilderTab.STUDIO.route
                    ) {
                        composable(BuilderTab.STUDIO.route) {
                            StudioScreen(
                                promptText = promptText,
                                appType = appType,
                                promptLanguage = promptLanguage,
                                attachments = attachments,
                                settingsDraft = settingsDraft,
                                generationState = generationState,
                                agentSteps = agentSteps,
                                onPromptChange = viewModel::updatePromptText,
                                onVoiceTranscript = viewModel::appendVoiceTranscript,
                                onAppTypeChange = viewModel::updateAppType,
                                onLanguageChange = viewModel::updatePromptLanguage,
                                onImagesPicked = { uris -> viewModel.addImagesFromUris(context, uris) },
                                onRemoveAttachment = viewModel::removeAttachment,
                                onSettingsChange = viewModel::updateSettingsDraft,
                                onGenerateClick = {
                                    viewModel.generateNewProject(
                                        context = context,
                                        onNavigateToPreview = { navigateToTab(BuilderTab.PREVIEW) }
                                    )
                                },
                                onError = viewModel::showToast
                            )
                        }

                        composable(BuilderTab.PREVIEW.route) {
                            PreviewScreen(
                                project = activeProject,
                                projectFiles = activeFiles,
                                previewDevice = previewDevice,
                                reloadNonce = reloadNonce,
                                consoleLogs = consoleLogs,
                                aiEditInstruction = aiEditInstruction,
                                generationState = generationState,
                                agentSteps = agentSteps,
                                copilotPhase = copilotPhase,
                                onDeviceChange = viewModel::updatePreviewDevice,
                                onReloadPreview = viewModel::triggerPreviewReload,
                                onRegenerateProject = { viewModel.regenerateActiveProject(context) },
                                onEditInstructionChange = viewModel::updateAiEditInstruction,
                                onEditVoiceTranscript = viewModel::appendEditVoiceTranscript,
                                onSubmitCopilotReply = { overridePrompt ->
                                    viewModel.submitCopilotReply(context, overridePrompt)
                                },
                                onPublishProject = viewModel::publishActiveProject,
                                onReopenReview = viewModel::reopenReviewFromPublished,
                                onConsoleLog = viewModel::addConsoleLog,
                                onNavigateToBuilder = { navigateToTab(BuilderTab.STUDIO) },
                                onNavigateToExport = { navigateToTab(BuilderTab.CODE) },
                                onToast = viewModel::showToast
                            )
                        }

                        composable(BuilderTab.CODE.route) {
                            CodeExportScreen(
                                project = activeProject,
                                files = activeFiles,
                                onToast = viewModel::showToast,
                                onNavigateToBuilder = { navigateToTab(BuilderTab.STUDIO) }
                            )
                        }

                        composable(BuilderTab.PROJECTS.route) {
                            ProjectsDashboardScreen(
                                projectsState = projectsState,
                                historyState = historyState,
                                activeProjectId = activeProject?.id,
                                onNewProjectClick = {
                                    viewModel.startNewProjectDraft()
                                    navigateToTab(BuilderTab.STUDIO)
                                },
                                onOpenProject = { project ->
                                    viewModel.selectProject(project)
                                    navigateToTab(BuilderTab.PREVIEW)
                                },
                                onReusePrompt = { historicalPrompt ->
                                    viewModel.updatePromptText(historicalPrompt)
                                    navigateToTab(BuilderTab.STUDIO)
                                },
                                onSaveProjectSettings = { id, name, type, settings ->
                                    viewModel.updateActiveProjectSettings(id, name, type, settings)
                                },
                                onDeleteProject = viewModel::deleteProject
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioTopBar(
    activeProjectName: String?
) {
    Surface(
        color = ObsidianSurface.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, GlassBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(StudioBrushes.primaryGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Prompt2App AI",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            maxLines = 1
                        )
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(EmeraldMint)
                        )
                    }
                    Text(
                        text = if (!activeProjectName.isNullOrBlank()) "Active: $activeProjectName" else "Direct Studio • No Login",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = EmeraldContainer.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, EmeraldMint.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AllInclusive,
                        contentDescription = "Unlimited free access",
                        tint = EmeraldMint,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Free",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldMint
                    )
                }
            }
        }
    }
}

private fun tabIcon(tab: BuilderTab, selected: Boolean) = when (tab) {
    BuilderTab.STUDIO -> if (selected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
    BuilderTab.PREVIEW -> if (selected) Icons.Filled.PlayCircle else Icons.Outlined.PlayCircle
    BuilderTab.CODE -> if (selected) Icons.Filled.Code else Icons.Outlined.Code
    BuilderTab.PROJECTS -> if (selected) Icons.Filled.FolderCopy else Icons.Outlined.FolderCopy
}
