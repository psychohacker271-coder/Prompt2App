package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.R
import com.example.model.AgentPipelineStep
import com.example.model.AppType
import com.example.model.GenerationState
import com.example.model.ProjectSettingsDraft
import com.example.model.PromptLanguage
import com.example.model.ReferenceImageAttachment
import com.example.ui.components.FreeUnlimitedBadge
import com.example.ui.components.GenerationProgressBanner
import com.example.ui.components.GlassCard
import com.example.ui.components.VoicePromptMicButton
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepIndigoContainer
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderStrong
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.RoseCoral
import com.example.ui.theme.StudioBrushes
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private data class StarterTemplate(
    val title: String,
    val appType: AppType,
    val prompt: String
)

private val starterTemplates = listOf(
    StarterTemplate(
        title = "SaaS Dashboard",
        appType = AppType.WEB_APP,
        prompt = "Build a sleek dark SaaS analytics dashboard with revenue KPI cards, interactive monthly chart, customer filter table, and team invite modal."
    ),
    StarterTemplate(
        title = "किराना / Store (Hindi)",
        appType = AppType.WEBSITE,
        prompt = "एक आधुनिक भारतीय किराना और ऑर्गेनिक स्टोर की वेबसाइट बनाओ जिसमें प्रोडक्ट कैटलॉग, सर्च, कार्ट और व्हाट्सएप ऑर्डर फॉर्म हो। सारा टेक्स्ट हिंदी में हो।"
    ),
    StarterTemplate(
        title = "Habit & Task PWA",
        appType = AppType.ANDROID_PWA,
        prompt = "Create a mobile-first habit tracker and daily planner app with streak counter, category filters, progress rings, and localStorage persistence."
    ),
    StarterTemplate(
        title = "Portfolio + Booking",
        appType = AppType.WEBSITE,
        prompt = "Design a futuristic creative agency portfolio with glassmorphism hero, filterable case studies, pricing calculator, and booking inquiry form."
    )
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioScreen(
    promptText: String,
    appType: AppType,
    promptLanguage: PromptLanguage,
    attachments: List<ReferenceImageAttachment>,
    settingsDraft: ProjectSettingsDraft,
    generationState: GenerationState,
    agentSteps: List<AgentPipelineStep>,
    onPromptChange: (String) -> Unit,
    onVoiceTranscript: (String) -> Unit,
    onAppTypeChange: (AppType) -> Unit,
    onLanguageChange: (PromptLanguage) -> Unit,
    onImagesPicked: (List<android.net.Uri>) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onSettingsChange: (ProjectSettingsDraft) -> Unit,
    onGenerateClick: () -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    var showSettingsExpanded by remember { mutableStateOf(false) }
    var inspectingAttachment by remember { mutableStateOf<ReferenceImageAttachment?>(null) }

    val multiPhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 5)
    ) { uris ->
        if (uris.isNotEmpty()) {
            onImagesPicked(uris)
        }
    }

    val isGenerating = generationState is GenerationState.InProgress

    if (inspectingAttachment != null) {
        BackHandler { inspectingAttachment = null }
        Dialog(onDismissRequest = { inspectingAttachment = null }) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = ObsidianCard,
                border = BorderStroke(1.dp, GlassBorderStrong)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${inspectingAttachment!!.formatLabel()} • ${inspectingAttachment!!.displayName}",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { inspectingAttachment = null }) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close image preview",
                                tint = TextSecondary
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    AsyncImage(
                        model = inspectingAttachment!!.uri,
                        contentDescription = "Full reference image preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(ObsidianBg)
                    )
                }
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 840.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner Card
            Surface(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, GlassBorder),
                color = ObsidianCard,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(132.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_studio),
                        contentDescription = "Prompt2App AI Studio header art",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        ObsidianBg.copy(alpha = 0.92f),
                                        ObsidianBg.copy(alpha = 0.65f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        FreeUnlimitedBadge()
                        Column {
                            Text(
                                text = "Build Any App or Website",
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = "Upload reference UI + describe in English or हिंदी",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // Target Type & Language Row
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Output Format",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppType.entries.forEach { type ->
                        val selected = type == appType
                        FilterChip(
                            selected = selected,
                            onClick = { onAppTypeChange(type) },
                            label = {
                                Text(
                                    text = type.label,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DeepIndigoContainer,
                                selectedLabelColor = CyberCyan,
                                containerColor = ObsidianCardElevated,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                selectedBorderColor = CyberCyan,
                                borderColor = GlassBorder
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("app_type_${type.name.lowercase()}")
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Language,
                        contentDescription = null,
                        tint = ElectricViolet,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Prompt & UI Language",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary
                    )
                }
                Spacer(Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PromptLanguage.entries.forEach { lang ->
                        val selected = lang == promptLanguage
                        FilterChip(
                            selected = selected,
                            onClick = { onLanguageChange(lang) },
                            label = { Text(lang.label, style = MaterialTheme.typography.labelMedium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricViolet.copy(alpha = 0.22f),
                                selectedLabelColor = TextPrimary,
                                containerColor = ObsidianCardElevated,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                selectedBorderColor = ElectricViolet,
                                borderColor = GlassBorder
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("lang_${lang.name.lowercase()}")
                        )
                    }
                }
            }

            // Large Prompt Input + Voice-to-Text
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = GlassBorderStrong
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "App / Website Prompt",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Type or speak in English, हिंदी, or Hinglish",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    VoicePromptMicButton(
                        language = promptLanguage,
                        onTranscript = onVoiceTranscript,
                        onError = onError,
                        testTag = "studio_voice_input_button"
                    )
                }

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = promptText,
                    onValueChange = onPromptChange,
                    placeholder = {
                        Text(
                            text = stringResource(R.string.prompt_hint),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                    },
                    minLines = 5,
                    maxLines = 10,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = GlassBorder,
                        focusedContainerColor = ObsidianBg.copy(alpha = 0.7f),
                        unfocusedContainerColor = ObsidianBg.copy(alpha = 0.55f),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = CyberCyan
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("prompt_input_field")
                )

                Spacer(Modifier.height(10.dp))

                Text(
                    text = "Quick Starters",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(starterTemplates) { tpl ->
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ObsidianCardElevated,
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier
                                .clickable {
                                    onPromptChange(tpl.prompt)
                                    onAppTypeChange(tpl.appType)
                                }
                                .testTag("starter_chip_${tpl.title.take(8).lowercase()}")
                        ) {
                            Text(
                                text = tpl.title,
                                style = MaterialTheme.typography.labelMedium,
                                color = CyberCyan,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            // Reference Images Upload & Preview
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Reference Images (${attachments.size}/5)",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Supports PNG, JPG, JPEG & WEBP • Tap preview to inspect",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            multiPhotoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("upload_reference_images_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AddPhotoAlternate,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text("Add Images", color = CyberCyan)
                    }
                }

                if (attachments.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(attachments, key = { it.id }) { attachment ->
                            Box(
                                modifier = Modifier
                                    .size(width = 112.dp, height = 122.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(ObsidianCardElevated)
                                    .clickable { inspectingAttachment = attachment }
                                    .testTag("reference_image_preview_${attachment.id}")
                            ) {
                                AsyncImage(
                                    model = attachment.uri,
                                    contentDescription = "Reference image ${attachment.displayName}",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Surface(
                                    color = ObsidianBg.copy(alpha = 0.85f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(6.dp)
                                ) {
                                    Text(
                                        text = attachment.formatLabel(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberCyan,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Surface(
                                    shape = CircleShape,
                                    color = ObsidianBg.copy(alpha = 0.85f),
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(28.dp)
                                        .clickable { onRemoveAttachment(attachment.id) }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.Close,
                                            contentDescription = "Remove image",
                                            tint = RoseCoral,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Project Generation Settings (Collapsible)
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                onClick = { showSettingsExpanded = !showSettingsExpanded }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Tune,
                            contentDescription = null,
                            tint = ElectricViolet
                        )
                        Column {
                            Text(
                                text = "Project Settings",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = "Backend starter, responsive layout, theme mode",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                    Icon(
                        imageVector = if (showSettingsExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = "Toggle project settings",
                        tint = TextSecondary
                    )
                }

                AnimatedVisibility(visible = showSettingsExpanded) {
                    Column(
                        modifier = Modifier.padding(top = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SettingToggleRow(
                            title = "Include Backend & DB Starter",
                            subtitle = "Generates Express/SQLite & localStorage persistence",
                            checked = settingsDraft.includeBackend,
                            onCheckedChange = { onSettingsChange(settingsDraft.copy(includeBackend = it)) }
                        )
                        SettingToggleRow(
                            title = "Responsive Breakpoints",
                            subtitle = "Optimize for Mobile, Tablet & Desktop",
                            checked = settingsDraft.responsive,
                            onCheckedChange = { onSettingsChange(settingsDraft.copy(responsive = it)) }
                        )
                        SettingToggleRow(
                            title = "Prefer Futuristic Dark Theme",
                            subtitle = "Matches reference image palette first",
                            checked = settingsDraft.darkTheme,
                            onCheckedChange = { onSettingsChange(settingsDraft.copy(darkTheme = it)) }
                        )
                    }
                }
            }

            // Generation Progress or Error
            when (generationState) {
                is GenerationState.InProgress -> {
                    GenerationProgressBanner(
                        stageLabel = generationState.stageLabel,
                        steps = agentSteps
                    )
                }
                is GenerationState.Failed -> {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, RoseCoral.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = generationState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = RoseCoral,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
                else -> Unit
            }

            // Generate Primary CTA
            Button(
                onClick = onGenerateClick,
                enabled = !isGenerating,
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = TextPrimary,
                    disabledContainerColor = ObsidianCardElevated
                ),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("generate_app_button")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            if (isGenerating) Brush.linearGradient(listOf(ObsidianCardElevated, ObsidianCardElevated))
                            else StudioBrushes.primaryGradient,
                            shape = RoundedCornerShape(18.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = CyberCyan,
                                strokeWidth = 2.5.dp
                            )
                            Text(
                                text = "Generating with Gemini AI...",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = TextPrimary
                            )
                            Text(
                                text = "Generate ${appType.label} (Free & Unlimited)",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
