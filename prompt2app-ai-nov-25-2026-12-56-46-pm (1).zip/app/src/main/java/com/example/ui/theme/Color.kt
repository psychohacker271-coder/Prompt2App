package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Neural Studio Palette
val ObsidianBg = Color(0xFF060814)
val ObsidianSurface = Color(0xFF0C1024)
val ObsidianSurfaceVariant = Color(0xFF141B38)
val ObsidianCard = Color(0xFF101630)
val ObsidianCardElevated = Color(0xFF182147)

val ElectricViolet = Color(0xFF8B5CF6)
val ElectricVioletLight = Color(0xFFA78BFA)
val CyberCyan = Color(0xFF38BDF8)
val NeonIndigo = Color(0xFF6366F1)
val DeepIndigoContainer = Color(0xFF251E54)

val TextPrimary = Color(0xFFF4F6FF)
val TextSecondary = Color(0xFFA5B0D6)
val TextMuted = Color(0xFF6E7AA6)

val GlassBorder = Color(0x26A5B4FC)
val GlassBorderStrong = Color(0x4D8B5CF6)
val GlassHighlight = Color(0x14FFFFFF)

val EmeraldMint = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF0A3327)
val AmberGlow = Color(0xFFF59E0B)
val RoseCoral = Color(0xFFF43F5E)
val RoseContainer = Color(0xFF421223)
