package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppType
import com.example.model.GeneratedProject
import com.example.model.ProjectSettingsDraft
import com.example.model.PromptHistoryEntry
import com.example.model.UiState
import com.example.ui.components.GlassCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepIndigoContainer
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.RoseCoral
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProjectsDashboardScreen(
    projectsState: UiState<List<GeneratedProject>>,
    historyState: UiState<List<PromptHistoryEntry>>,
    activeProjectId: String?,
    onNewProjectClick: () -> Unit,
    onOpenProject: (GeneratedProject) -> Unit,
    onReusePrompt: (String) -> Unit,
    onSaveProjectSettings: (String, String, AppType, ProjectSettingsDraft) -> Unit,
    onDeleteProject: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var editingSettingsProject by remember { mutableStateOf<GeneratedProject?>(null) }
    var deletingProject by remember { mutableStateOf<GeneratedProject?>(null) }

    if (editingSettingsProject != null) {
        val target = editingSettingsProject!!
        var name by remember(target.id) { mutableStateOf(target.name) }
        var appType by remember(target.id) { mutableStateOf(target.resolvedAppType()) }
        var includeBackend by remember(target.id) { mutableStateOf(target.settingsIncludeBackend) }
        var responsive by remember(target.id) { mutableStateOf(target.settingsResponsive) }
        var darkTheme by remember(target.id) { mutableStateOf(target.settingsDarkTheme) }

        AlertDialog(
            onDismissRequest = { editingSettingsProject = null },
            containerColor = ObsidianCard,
            title = { Text("Project Settings", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Project Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Backend & DB Starter", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = includeBackend, onCheckedChange = { includeBackend = it })
                    }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Responsive Layout", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = responsive, onCheckedChange = { responsive = it })
                    }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Dark Theme Mode", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = darkTheme, onCheckedChange = { darkTheme = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveProjectSettings(
                            target.id,
                            name,
                            appType,
                            ProjectSettingsDraft(includeBackend, responsive, darkTheme)
                        )
                        editingSettingsProject = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingSettingsProject = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    if (deletingProject != null) {
        val target = deletingProject!!
        AlertDialog(
            onDismissRequest = { deletingProject = null },
            containerColor = ObsidianCard,
            title = { Text("Delete Project?", color = TextPrimary) },
            text = {
                Text(
                    "Remove \"${target.name}\" and its generated files from your workspace? This cannot be undone.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteProject(target.id)
                        deletingProject = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseCoral)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingProject = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 880.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Action Row + Search
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Workspace Dashboard",
                        style = MaterialTheme.typography.headlineSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "My Projects, Recent Builds & Prompt History",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Button(
                    onClick = onNewProjectClick,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("dashboard_new_project_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New Project")
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search projects by name or prompt...", color = TextMuted) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = CyberCyan) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedContainerColor = ObsidianCard,
                    unfocusedContainerColor = ObsidianCard,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_search_input")
            )

            // Projects Section
            when (projectsState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = CyberCyan)
                    }
                }
                is UiState.Error -> {
                    GlassCard(borderColor = RoseCoral.copy(alpha = 0.5f)) {
                        Text(projectsState.message, color = RoseCoral, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                is UiState.Success -> {
                    val allProjects = projectsState.data
                    val filtered = remember(allProjects, searchQuery) {
                        val q = searchQuery.trim().lowercase()
                        if (q.isBlank()) allProjects
                        else allProjects.filter {
                            it.name.lowercase().contains(q) || it.lastPrompt.lowercase().contains(q)
                        }
                    }

                    if (allProjects.isEmpty()) {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Image(
                                painter = painterResource(id = R.drawable.img_empty_projects),
                                contentDescription = "Empty projects workspace",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .clip(RoundedCornerShape(16.dp))
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = "Your workspace is ready",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Generate your first app or website using text, voice, or reference screenshots. Every build is saved here automatically.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    } else {
                        // Recent Projects Horizontal Strip
                        Text(
                            text = "Recent Projects",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(allProjects.take(5), key = { "recent_${it.id}" }) { project ->
                                val isActive = project.id == activeProjectId
                                GlassCard(
                                    modifier = Modifier
                                        .width(230.dp)
                                        .testTag("recent_project_card_${project.id}"),
                                    borderColor = if (isActive) CyberCyan else GlassBorder,
                                    onClick = { onOpenProject(project) }
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(color = DeepIndigoContainer, shape = RoundedCornerShape(8.dp)) {
                                            Text(
                                                text = project.resolvedAppType().label,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CyberCyan,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                        Text(
                                            text = "v${project.version}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextMuted
                                        )
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = project.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = project.summary,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        // My Projects Full List
                        Text(
                            text = "My Projects (${filtered.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        filtered.forEach { project ->
                            val isActive = project.id == activeProjectId
                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("project_card_${project.id}"),
                                borderColor = if (isActive) CyberCyan else GlassBorder,
                                onClick = { onOpenProject(project) }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = project.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${project.resolvedAppType().label} • ${project.fileCount} files • v${project.version}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CyberCyan
                                        )
                                    }
                                    Row {
                                        IconButton(
                                            onClick = { editingSettingsProject = project },
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Icon(
                                                Icons.Filled.Settings,
                                                contentDescription = "Project settings",
                                                tint = TextSecondary
                                            )
                                        }
                                        IconButton(
                                            onClick = { deletingProject = project },
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Icon(
                                                Icons.Filled.DeleteOutline,
                                                contentDescription = "Delete project",
                                                tint = RoseCoral
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = project.lastPrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Prompt History Section
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.History, contentDescription = null, tint = ElectricViolet)
                Text(
                    text = "Prompt History",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
            }

            when (historyState) {
                is UiState.Loading -> {
                    Text("Loading prompt history...", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
                is UiState.Error -> {
                    Text(historyState.message, style = MaterialTheme.typography.bodySmall, color = RoseCoral)
                }
                is UiState.Success -> {
                    val entries = historyState.data
                    if (entries.isEmpty()) {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Your generation & AI edit prompts will appear here so you can reuse or branch any idea anytime.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    } else {
                        entries.take(15).forEach { entry ->
                            GlassCard(
                                modifier = Modifier.fillMaxWidth(),
                                containerColor = ObsidianCardElevated.copy(alpha = 0.7f),
                                onClick = { onReusePrompt(entry.prompt) }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${entry.projectName} • ${entry.resolvedActionType().label} (v${entry.version})",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = CyberCyan,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    val dateStr = formatTimestamp(Date(entry.createdAtMillis))
                                    Text(
                                        text = dateStr,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = entry.prompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Tap to reuse this prompt in Builder",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricViolet
                                )
                            }
                        }
                    }
                }
            }

            // Free & Open-Source Transparency Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = EmeraldContainer.copy(alpha = 0.45f),
                border = BorderStroke(1.dp, EmeraldMint.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.AllInclusive, contentDescription = null, tint = EmeraldMint)
                        Text(
                            text = "Free, Direct & Unlimited",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                    }
                    Text(
                        text = "• No login or account needed — start typing or speaking prompts right away and save unlimited projects on your device.\n• Zero Prompt2App credits, subscriptions, or paywalls.\n• Free tier note: Google Gemini 3.8 Flash rate limits can apply on extreme burst traffic; Android APK compilation runs via the included free GitHub Actions CI workflow or locally in Android Studio.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

private fun formatTimestamp(date: Date): String {
    return SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(date)
}
