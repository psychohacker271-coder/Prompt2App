package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ExportManager
import com.example.model.GeneratedProject
import com.example.model.ProjectFile
import com.example.ui.components.GlassCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepIndigoContainer
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderStrong
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun CodeExportScreen(
    project: GeneratedProject?,
    files: List<ProjectFile>,
    onToast: (String) -> Unit,
    onNavigateToBuilder: () -> Unit
) {
    if (project == null) {
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            GlassCard(modifier = Modifier.widthIn(max = 460.dp)) {
                Text("No Project Selected", style = MaterialTheme.typography.headlineSmall, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Generate an app or select a saved project from your Dashboard to inspect source files and export ZIP bundles.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onNavigateToBuilder,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Create New Project")
                }
            }
        }
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val effectiveFiles = remember(project, files) {
        if (files.isNotEmpty()) files
        else listOf(
            ProjectFile(
                id = "fallback_index",
                path = "index.html",
                language = "html",
                content = project.previewHtml
            )
        )
    }

    var selectedFilePath by remember(project.id, effectiveFiles) {
        mutableStateOf(effectiveFiles.firstOrNull()?.path ?: "index.html")
    }
    val currentFile = effectiveFiles.firstOrNull { it.path == selectedFilePath } ?: effectiveFiles.first()

    var pendingZipBytes by remember { mutableStateOf<ByteArray?>(null) }

    val saveZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val bytes = pendingZipBytes
        pendingZipBytes = null
        if (uri != null && bytes != null) {
            scope.launch {
                val res = ExportManager.writeBytesToUri(context, uri, bytes)
                res.fold(
                    onSuccess = { onToast("ZIP saved successfully (${bytes.size / 1024} KB)") },
                    onFailure = { e -> onToast(e.localizedMessage ?: "Failed to save ZIP") }
                )
            }
        }
    }

    val saveHtmlLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/html")
    ) { uri ->
        val bytes = pendingZipBytes
        pendingZipBytes = null
        if (uri != null && bytes != null) {
            scope.launch {
                val res = ExportManager.writeBytesToUri(context, uri, bytes)
                res.fold(
                    onSuccess = { onToast("Standalone HTML app saved!") },
                    onFailure = { e -> onToast(e.localizedMessage ?: "Failed to save HTML") }
                )
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 880.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Export Actions Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = GlassBorderStrong
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.FolderZip, contentDescription = null, tint = CyberCyan)
                    Column {
                        Text(
                            text = "Export & Download (${project.name})",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "${effectiveFiles.size} source files • Production-ready free open-source code",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                // Website ZIP Export Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            scope.launch {
                                val bytes = ExportManager.buildWebsiteZipBytes(project, effectiveFiles)
                                pendingZipBytes = bytes
                                val slug = ExportManager.safeFileSlug(project.name)
                                saveZipLauncher.launch("$slug-website-v${project.version}.zip")
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("download_website_zip_button")
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Download ZIP")
                    }

                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                val bytes = ExportManager.buildWebsiteZipBytes(project, effectiveFiles)
                                val slug = ExportManager.safeFileSlug(project.name)
                                val fileName = "$slug-website-v${project.version}.zip"
                                val uriRes = ExportManager.createShareableZipUri(context, fileName, bytes)
                                uriRes.fold(
                                    onSuccess = { shareUri ->
                                        val intent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/zip"
                                            putExtra(Intent.EXTRA_STREAM, shareUri)
                                            putExtra(Intent.EXTRA_SUBJECT, "${project.name} Source Code ZIP")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "Share Website ZIP"))
                                    },
                                    onFailure = { e -> onToast(e.localizedMessage ?: "Share failed") }
                                )
                            }
                        },
                        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("share_website_zip_button")
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = "Share ZIP", tint = CyberCyan, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Share", color = CyberCyan)
                    }
                }

                Spacer(Modifier.height(10.dp))

                OutlinedButton(
                    onClick = {
                        pendingZipBytes = ExportManager.buildStandaloneHtmlBytes(project)
                        val slug = ExportManager.safeFileSlug(project.name)
                        saveHtmlLauncher.launch("$slug-standalone.html")
                    },
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("download_standalone_html_button")
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Download Single-File Runnable App (.html)", color = CyberCyan)
                }

                Spacer(Modifier.height(10.dp))

                // Android APK Wrapper Workflow
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = EmeraldContainer.copy(alpha = 0.45f),
                    border = BorderStroke(1.dp, EmeraldMint.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.Android, contentDescription = null, tint = EmeraldMint)
                            Text(
                                text = "Android APK Export & Auto-APK Link Workflow",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "Downloads a complete Android Studio / Gradle Kotlin WebView project pre-bundled with your app AND a free GitHub Actions workflow (.github/workflows/build-apk.yml) that automatically compiles a downloadable .apk file when pushed to GitHub.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val bytes = ExportManager.buildAndroidWrapperZipBytes(project, effectiveFiles)
                                    pendingZipBytes = bytes
                                    val slug = ExportManager.safeFileSlug(project.name)
                                    saveZipLauncher.launch("$slug-android-apk-project.zip")
                                }
                            },
                            border = BorderStroke(1.dp, EmeraldMint),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("export_android_wrapper_button")
                        ) {
                            Icon(Icons.Filled.Android, contentDescription = null, tint = EmeraldMint, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Download Android APK Wrapper Project (.zip)", color = EmeraldMint)
                        }
                    }
                }
            }

            // Source Code Explorer Card
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Project Source Files",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText(currentFile.path, currentFile.content))
                            onToast("Copied ${currentFile.path} to clipboard")
                        },
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("copy_source_file_button")
                    ) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = "Copy file source", tint = CyberCyan)
                    }
                }

                Spacer(Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(effectiveFiles, key = { it.path }) { file ->
                        val selected = file.path == currentFile.path
                        FilterChip(
                            selected = selected,
                            onClick = { selectedFilePath = file.path },
                            label = { Text(file.path, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DeepIndigoContainer,
                                selectedLabelColor = CyberCyan,
                                containerColor = ObsidianCardElevated,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                selectedBorderColor = CyberCyan,
                                borderColor = GlassBorder
                            ),
                            modifier = Modifier.testTag("code_file_tab_${file.path}")
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ObsidianBg,
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    SelectionContainer {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp)
                                .verticalScroll(rememberScrollState())
                                .horizontalScroll(rememberScrollState())
                                .padding(14.dp)
                        ) {
                            Text(
                                text = currentFile.content,
                                fontFamily = JetBrainsMonoFontFamily,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // Free Deployment Instructions Card
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.CloudUpload, contentDescription = null, tint = ElectricViolet)
                    Text(
                        text = "Free Deployment Instructions",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = project.deploymentGuide.ifBlank {
                        "Unzip the exported website bundle and deploy to Cloudflare Pages, Netlify Drop, Vercel, or GitHub Pages for free."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                if (project.techStack.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "Tech Stack: ${project.techStack.joinToString(" • ")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
