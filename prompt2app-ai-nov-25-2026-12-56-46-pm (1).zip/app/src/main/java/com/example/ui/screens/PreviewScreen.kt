package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloseFullscreen
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TabletAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.data.ExportManager
import com.example.model.AgentPipelineStep
import com.example.model.ConsoleLogEntry
import com.example.model.CopilotReviewPhase
import com.example.model.GeneratedProject
import com.example.model.GenerationState
import com.example.model.PreviewDevice
import com.example.model.ProjectFile
import com.example.ui.components.GenerationProgressBanner
import com.example.ui.components.GlassCard
import com.example.ui.components.VoicePromptMicButton
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepIndigoContainer
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderStrong
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.RoseCoral
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

private val quickAiEditActions = listOf(
    "Add Login" to "Add a working Login and Sign Up flow with form validation and session persistence in localStorage.",
    "Change Colors" to "Refresh the color palette to a striking new complementary accent theme while keeping high contrast.",
    "Add Feature" to "Add a useful interactive feature (search, filter, or analytics summary) fitting this app.",
    "Change Design" to "Upgrade the visual design with cleaner spacing, modern glassmorphism cards, and sharper hierarchy.",
    "Make Responsive" to "Improve responsive CSS layout so Mobile (390px), Tablet (768px), and Desktop (1280px) all render cleanly.",
    "Fix Errors" to "Inspect and fix any JavaScript, layout, or UI interaction errors so every button and form works cleanly."
)

@Composable
fun PreviewScreen(
    project: GeneratedProject?,
    projectFiles: List<ProjectFile>,
    previewDevice: PreviewDevice,
    reloadNonce: Int,
    consoleLogs: List<ConsoleLogEntry>,
    aiEditInstruction: String,
    generationState: GenerationState,
    agentSteps: List<AgentPipelineStep>,
    copilotPhase: CopilotReviewPhase,
    onDeviceChange: (PreviewDevice) -> Unit,
    onReloadPreview: () -> Unit,
    onRegenerateProject: () -> Unit,
    onEditInstructionChange: (String) -> Unit,
    onEditVoiceTranscript: (String) -> Unit,
    onSubmitCopilotReply: (String?) -> Unit,
    onPublishProject: () -> Unit,
    onReopenReview: () -> Unit,
    onConsoleLog: (ConsoleLogEntry) -> Unit,
    onNavigateToBuilder: () -> Unit,
    onNavigateToExport: () -> Unit,
    onToast: (String) -> Unit
) {
    if (project == null) {
        EmptyPreviewState(onNavigateToBuilder = onNavigateToBuilder)
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isFullscreen by remember { mutableStateOf(false) }
    var showConsole by remember { mutableStateOf(false) }
    val isEditing = generationState is GenerationState.InProgress

    if (isFullscreen) {
        BackHandler { isFullscreen = false }
    }

    var pendingExportBytes by remember { mutableStateOf<ByteArray?>(null) }
    val saveZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val bytes = pendingExportBytes
        pendingExportBytes = null
        if (uri != null && bytes != null) {
            scope.launch {
                val res = ExportManager.writeBytesToUri(context, uri, bytes)
                res.fold(
                    onSuccess = { onToast("Saved ZIP (${bytes.size / 1024} KB)") },
                    onFailure = { e -> onToast(e.localizedMessage ?: "Failed to save ZIP") }
                )
            }
        }
    }

    val saveHtmlLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/html")
    ) { uri ->
        val bytes = pendingExportBytes
        pendingExportBytes = null
        if (uri != null && bytes != null) {
            scope.launch {
                val res = ExportManager.writeBytesToUri(context, uri, bytes)
                res.fold(
                    onSuccess = { onToast("Standalone HTML app saved!") },
                    onFailure = { e -> onToast(e.localizedMessage ?: "Failed to save HTML") }
                )
            }
        }
    }

    val errorCount = consoleLogs.count { it.level == "ERROR" }
    val showPublishedHub = copilotPhase == CopilotReviewPhase.PUBLISHED ||
        (copilotPhase == CopilotReviewPhase.NONE && project.isPublished())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                horizontal = if (isFullscreen) 4.dp else 14.dp,
                vertical = if (isFullscreen) 4.dp else 10.dp
            ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Top Toolbar: Project Info + Viewport Switcher + Actions
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = ObsidianCard,
            border = BorderStroke(1.dp, GlassBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = project.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                color = if (project.isPublished()) EmeraldContainer else DeepIndigoContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (project.isPublished()) "PUBLISHED v${project.version}" else "DRAFT v${project.version}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (project.isPublished()) EmeraldMint else CyberCyan,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = project.summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onReloadPreview,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("reload_preview_button")
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Reload live preview", tint = CyberCyan)
                        }
                        IconButton(
                            onClick = { isFullscreen = !isFullscreen },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("fullscreen_preview_button")
                        ) {
                            Icon(
                                imageVector = if (isFullscreen) Icons.Filled.CloseFullscreen else Icons.Filled.Fullscreen,
                                contentDescription = "Toggle fullscreen preview",
                                tint = TextPrimary
                            )
                        }
                    }
                }

                // Device Breakpoint Switcher + Regenerate + Export
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PreviewDevice.entries.forEach { device ->
                        val selected = device == previewDevice
                        val icon = when (device) {
                            PreviewDevice.MOBILE -> Icons.Filled.PhoneAndroid
                            PreviewDevice.TABLET -> Icons.Filled.TabletAndroid
                            PreviewDevice.DESKTOP -> Icons.Filled.DesktopWindows
                        }
                        FilterChip(
                            selected = selected,
                            onClick = { onDeviceChange(device) },
                            leadingIcon = {
                                Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            label = { Text("${device.label} (${device.widthPx}px)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DeepIndigoContainer,
                                selectedLabelColor = CyberCyan,
                                selectedLeadingIconColor = CyberCyan,
                                containerColor = ObsidianCardElevated,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                selectedBorderColor = CyberCyan,
                                borderColor = GlassBorder
                            ),
                            modifier = Modifier.testTag("viewport_${device.name.lowercase()}")
                        )
                    }

                    OutlinedButton(
                        onClick = onRegenerateProject,
                        enabled = !isEditing,
                        border = BorderStroke(1.dp, ElectricViolet.copy(alpha = 0.6f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("regenerate_button")
                    ) {
                        Icon(Icons.Filled.Replay, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Regenerate", color = TextPrimary, style = MaterialTheme.typography.labelMedium)
                    }

                    OutlinedButton(
                        onClick = onNavigateToExport,
                        border = BorderStroke(1.dp, EmeraldMint.copy(alpha = 0.6f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("goto_export_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, tint = EmeraldMint, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("All Files", color = EmeraldMint, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Live Interactive WebView Frame
        Surface(
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.5.dp, GlassBorderStrong),
            color = ObsidianBg,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ObsidianBg)
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                val density = LocalDensity.current
                val availablePx = with(density) { maxWidth.toPx().coerceAtLeast(320f) }
                val targetWidthPx = previewDevice.widthPx.toFloat()
                val scale = (availablePx / targetWidthPx).coerceIn(0.25f, 1.0f)

                val frameModifier = if (previewDevice == PreviewDevice.MOBILE) {
                    Modifier
                        .widthIn(max = 420.dp)
                        .fillMaxSize()
                        .clip(RoundedCornerShape(16.dp))
                } else {
                    Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(14.dp))
                }

                InteractivePreviewWebView(
                    rawHtml = project.previewHtml,
                    targetWidthPx = previewDevice.widthPx,
                    initialScalePercent = (scale * 100f).toInt().coerceIn(25, 100),
                    reloadKey = "${project.id}_${project.version}_${previewDevice.name}_$reloadNonce",
                    onConsoleLog = onConsoleLog,
                    modifier = frameModifier.testTag("live_preview_webview")
                )
            }
        }

        if (!isFullscreen) {
            // Collapsible Console Bar
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = ObsidianCard,
                border = BorderStroke(1.dp, if (errorCount > 0) RoseCoral.copy(alpha = 0.6f) else GlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showConsole = !showConsole },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                imageVector = Icons.Filled.BugReport,
                                contentDescription = null,
                                tint = if (errorCount > 0) RoseCoral else EmeraldMint,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (errorCount > 0) "$errorCount Runtime Issue(s) Detected" else "Console (${consoleLogs.size} logs)",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (errorCount > 0) RoseCoral else TextSecondary
                            )
                        }
                        if (errorCount > 0) {
                            TextButton(
                                onClick = {
                                    val errorSummary = consoleLogs
                                        .filter { it.level == "ERROR" }
                                        .joinToString("; ") { "Line ${it.lineNumber}: ${it.message}" }
                                    onSubmitCopilotReply("Fix these JavaScript/runtime errors: $errorSummary")
                                },
                                enabled = !isEditing
                            ) {
                                Text("Fix Errors with AI", color = CyberCyan, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }

                    AnimatedVisibility(visible = showConsole) {
                        Column(
                            modifier = Modifier
                                .padding(top = 6.dp)
                                .height(72.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (consoleLogs.isEmpty()) {
                                Text(
                                    text = "No console errors yet. Test buttons, navigation, and forms in the preview above.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            } else {
                                consoleLogs.forEach { entry ->
                                    val color = when (entry.level) {
                                        "ERROR" -> RoseCoral
                                        "WARNING" -> AmberGlow
                                        else -> TextSecondary
                                    }
                                    Text(
                                        text = "[${entry.level}] L${entry.lineNumber}: ${entry.message}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = color
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (generationState is GenerationState.InProgress && generationState.isEdit) {
                GenerationProgressBanner(
                    stageLabel = generationState.stageLabel,
                    steps = agentSteps
                )
            } else if (generationState is GenerationState.Failed) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = generationState.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = RoseCoral,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Conversational Copilot Review OR Published Download Center
            if (showPublishedHub) {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("published_download_hub"),
                    borderColor = EmeraldMint.copy(alpha = 0.65f),
                    containerColor = EmeraldContainer.copy(alpha = 0.42f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = EmeraldMint)
                            Column {
                                Text(
                                    text = "${project.name} Published!",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Download your Website ZIP, Standalone App, or APK Builder",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        TextButton(
                            onClick = onReopenReview,
                            modifier = Modifier.testTag("reopen_edit_button")
                        ) {
                            Icon(Icons.Filled.Edit, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Edit", color = CyberCyan)
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val bytes = ExportManager.buildWebsiteZipBytes(project, projectFiles)
                                    pendingExportBytes = bytes
                                    val slug = ExportManager.safeFileSlug(project.name)
                                    saveZipLauncher.launch("$slug-website-v${project.version}.zip")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("published_download_zip_button")
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Website .ZIP")
                        }

                        Button(
                            onClick = {
                                val bytes = ExportManager.buildStandaloneHtmlBytes(project)
                                pendingExportBytes = bytes
                                val slug = ExportManager.safeFileSlug(project.name)
                                saveHtmlLauncher.launch("$slug-app.html")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = ObsidianBg),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("published_download_html_button")
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Standalone .HTML")
                        }

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val bytes = ExportManager.buildAndroidWrapperZipBytes(project, projectFiles)
                                    pendingExportBytes = bytes
                                    val slug = ExportManager.safeFileSlug(project.name)
                                    saveZipLauncher.launch("$slug-apk-builder-v${project.version}.zip")
                                }
                            },
                            border = BorderStroke(1.dp, EmeraldMint),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("published_download_apk_project_button")
                        ) {
                            Icon(Icons.Filled.Android, contentDescription = null, tint = EmeraldMint, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("APK Builder .ZIP", color = EmeraldMint)
                        }

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val slug = ExportManager.safeFileSlug(project.name)
                                    val bytes = ExportManager.buildStandaloneHtmlBytes(project)
                                    val res = ExportManager.createShareableFileUri(context, "$slug.html", bytes)
                                    res.fold(
                                        onSuccess = { shareUri ->
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/html"
                                                putExtra(Intent.EXTRA_STREAM, shareUri)
                                                putExtra(Intent.EXTRA_SUBJECT, "${project.name} — Published App")
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Published App"))
                                        },
                                        onFailure = { e -> onToast(e.localizedMessage ?: "Share failed") }
                                    )
                                }
                            },
                            border = BorderStroke(1.dp, GlassBorderStrong),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("published_share_app_button")
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Share App", color = TextPrimary)
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Tip: APK Builder .ZIP includes a free GitHub Actions workflow (.github/workflows/build-apk.yml) that automatically compiles a downloadable .apk link when pushed to GitHub.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            } else {
                // Conversational AI Copilot Review & Publish Prompt Card
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = GlassBorderStrong
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoFixHigh,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Aur kuch add ya change karna hai kya?",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                        }
                        Button(
                            onClick = onPublishProject,
                            enabled = !isEditing,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldMint,
                                contentColor = ObsidianBg
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("copilot_confirm_publish_button")
                        ) {
                            Icon(Icons.Filled.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Theek hai, Publish!", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Tell me any changes to add, or tap \"Theek hai, Publish!\" (or type \"theek hai\") to publish & unlock downloads.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(quickAiEditActions) { (label, prompt) ->
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = ObsidianCardElevated,
                                border = BorderStroke(1.dp, GlassBorder),
                                modifier = Modifier
                                    .clickable(enabled = !isEditing) { onSubmitCopilotReply(prompt) }
                                    .testTag("quick_edit_${label.lowercase().replace(" ", "_")}")
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CyberCyan,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = aiEditInstruction,
                            onValueChange = onEditInstructionChange,
                            placeholder = {
                                Text(
                                    text = "Reply: add feature, change colors, or type 'theek hai' to publish...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = GlassBorder,
                                focusedContainerColor = ObsidianBg,
                                unfocusedContainerColor = ObsidianBg,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("ai_edit_input")
                        )

                        VoicePromptMicButton(
                            language = project.resolvedLanguage(),
                            onTranscript = onEditVoiceTranscript,
                            onError = onToast,
                            testTag = "ai_edit_voice_button"
                        )

                        Button(
                            onClick = { onSubmitCopilotReply(null) },
                            enabled = !isEditing && aiEditInstruction.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("apply_ai_edit_button")
                        ) {
                            if (isEditing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = TextPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send reply or edit", tint = TextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun InteractivePreviewWebView(
    rawHtml: String,
    targetWidthPx: Int,
    initialScalePercent: Int,
    reloadKey: String,
    onConsoleLog: (ConsoleLogEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    val preparedHtml = remember(rawHtml, targetWidthPx) {
        injectViewportMeta(rawHtml, targetWidthPx)
    }
    var lastLoadedKey by remember { mutableStateOf("") }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.builtInZoomControls = true
                settings.displayZoomControls = false

                webViewClient = object : WebViewClient() {
                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        if (request?.isForMainFrame == true) {
                            onConsoleLog(
                                ConsoleLogEntry(
                                    level = "ERROR",
                                    message = error?.description?.toString() ?: "Resource load error",
                                    lineNumber = 0,
                                    sourceId = "webview"
                                )
                            )
                        }
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                        consoleMessage?.let { msg ->
                            onConsoleLog(
                                ConsoleLogEntry(
                                    level = msg.messageLevel().name,
                                    message = msg.message(),
                                    lineNumber = msg.lineNumber(),
                                    sourceId = msg.sourceId().orEmpty()
                                )
                            )
                        }
                        return true
                    }
                }
            }
        },
        update = { webView ->
            if (lastLoadedKey != reloadKey) {
                lastLoadedKey = reloadKey
                webView.setInitialScale(if (targetWidthPx <= 420) 0 else initialScalePercent)
                webView.loadDataWithBaseURL(
                    "https://prompt2app.local/",
                    preparedHtml,
                    "text/html",
                    "UTF-8",
                    null
                )
            }
        }
    )
}

private fun injectViewportMeta(html: String, widthPx: Int): String {
    val viewportTag = if (widthPx <= 420) {
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
    } else {
        "<meta name=\"viewport\" content=\"width=$widthPx\">"
    }
    val regex = Regex("<meta\\s+name=[\"']viewport[\"'][^>]*>", RegexOption.IGNORE_CASE)
    return if (regex.containsMatchIn(html)) {
        regex.replace(html, viewportTag)
    } else if (html.contains("<head>", ignoreCase = true)) {
        html.replaceFirst("<head>", "<head>\n$viewportTag", ignoreCase = true)
    } else {
        "<!DOCTYPE html><html><head>$viewportTag</head><body>$html</body></html>"
    }
}

@Composable
private fun EmptyPreviewState(onNavigateToBuilder: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        GlassCard(modifier = Modifier.widthIn(max = 460.dp)) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_projects),
                contentDescription = "No project selected for preview",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "No App Generated Yet",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Describe an app or website in English or हिंदी, upload optional reference images, and test the live interactive output right here.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onNavigateToBuilder,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("empty_preview_start_button")
            ) {
                Text("Open AI Builder")
            }
        }
    }
}
