package com.example.data

import android.content.Context
import android.util.Log
import com.example.data.local.LocalProjectEntity
import com.example.data.local.LocalProjectFileEntity
import com.example.data.local.LocalPromptHistoryEntity
import com.example.data.local.ProjectDao
import com.example.data.local.Prompt2AppDatabase
import com.example.model.ActionType
import com.example.model.AiGenerationResult
import com.example.model.AppType
import com.example.model.GeneratedProject
import com.example.model.ProjectFile
import com.example.model.ProjectSettingsDraft
import com.example.model.PromptHistoryEntry
import com.example.model.PromptLanguage
import com.example.model.PublishStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class ProjectRepository(
    private val dao: ProjectDao
) {
    constructor(context: Context) : this(
        Prompt2AppDatabase.getInstance(context.applicationContext).projectDao()
    )

    fun observeProjects(): Flow<List<GeneratedProject>> =
        dao.observeProjects().map { rows -> rows.map { it.toDomain() } }

    fun observeProjectFiles(projectId: String): Flow<List<ProjectFile>> {
        require(projectId.isNotBlank())
        return dao.observeProjectFiles(projectId).map { rows -> rows.map { it.toDomain() } }
    }

    fun observePromptHistory(): Flow<List<PromptHistoryEntry>> =
        dao.observePromptHistory().map { rows -> rows.map { it.toDomain() } }

    suspend fun saveNewProject(
        prompt: String,
        appType: AppType,
        language: PromptLanguage,
        settings: ProjectSettingsDraft,
        imageCount: Int,
        result: AiGenerationResult
    ): Result<String> {
        return try {
            val now = System.currentTimeMillis()
            val projectId = UUID.randomUUID().toString()
            val sanitizedFiles = result.files.take(25)
            val sanitizedName = result.projectName.trim().ifBlank { "Untitled App" }.take(120)
            val sanitizedPrompt = prompt.trim().ifBlank { "Generated application" }.take(12000)
            val sanitizedSummary = result.summary.trim().take(3000)
            val sanitizedStack = result.techStack.map { it.take(60) }.filter { it.isNotBlank() }.take(15)

            val projectEntity = LocalProjectEntity(
                id = projectId,
                name = sanitizedName,
                summary = sanitizedSummary,
                appType = appType.name,
                promptLanguage = language.name,
                lastPrompt = sanitizedPrompt,
                techStack = sanitizedStack,
                primaryColorHex = result.primaryColorHex.take(20).ifBlank { "#8B5CF6" },
                accentColorHex = result.accentColorHex.take(20).ifBlank { "#38BDF8" },
                deploymentGuide = result.deploymentGuide.take(20000),
                previewHtml = result.previewHtml.take(400000),
                fileCount = sanitizedFiles.size.toLong(),
                version = 1L,
                settingsIncludeBackend = settings.includeBackend,
                settingsResponsive = settings.responsive,
                settingsDarkTheme = settings.darkTheme,
                publishStatus = PublishStatus.DRAFT.name,
                createdAtMillis = now,
                updatedAtMillis = now
            )

            val fileEntities = sanitizedFiles.mapIndexed { idx, fileSpec ->
                LocalProjectFileEntity(
                    id = "${projectId}_v1_file_$idx",
                    projectId = projectId,
                    path = fileSpec.path.take(200).ifBlank { "file_$idx.txt" },
                    language = fileSpec.language.take(40).ifBlank { "text" },
                    content = fileSpec.content.take(300000),
                    createdAtMillis = now,
                    updatedAtMillis = now
                )
            }

            val historyEntity = LocalPromptHistoryEntity(
                id = UUID.randomUUID().toString(),
                projectId = projectId,
                projectName = sanitizedName,
                prompt = sanitizedPrompt,
                actionType = ActionType.GENERATE.name,
                imageCount = imageCount.coerceIn(0, 10).toLong(),
                summary = sanitizedSummary,
                version = 1L,
                createdAtMillis = now
            )

            dao.saveProjectBundle(projectEntity, fileEntities, historyEntity)
            Result.success(projectId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "saveNewProject failed", e)
            Result.failure(e)
        }
    }

    suspend fun applyAiUpdateToProject(
        project: GeneratedProject,
        instruction: String,
        actionType: ActionType,
        imageCount: Int,
        result: AiGenerationResult
    ): Result<Unit> {
        return try {
            require(project.id.isNotBlank()) { "Project ID required" }
            val now = System.currentTimeMillis()
            val newVersion = (project.version + 1L).coerceAtMost(10000L)
            val sanitizedFiles = result.files.take(25)
            val sanitizedName = result.projectName.trim().ifBlank { project.name }.take(120)
            val sanitizedPrompt = instruction.trim().ifBlank { project.lastPrompt }.take(12000)
            val sanitizedSummary = result.summary.trim().take(3000)
            val sanitizedStack = result.techStack.map { it.take(60) }.filter { it.isNotBlank() }.take(15)

            val updatedProject = LocalProjectEntity(
                id = project.id,
                name = sanitizedName,
                summary = sanitizedSummary,
                appType = project.appType,
                promptLanguage = project.promptLanguage,
                lastPrompt = sanitizedPrompt,
                techStack = sanitizedStack,
                primaryColorHex = result.primaryColorHex.take(20).ifBlank { project.primaryColorHex },
                accentColorHex = result.accentColorHex.take(20).ifBlank { project.accentColorHex },
                deploymentGuide = result.deploymentGuide.take(20000),
                previewHtml = result.previewHtml.take(400000),
                fileCount = sanitizedFiles.size.toLong(),
                version = newVersion,
                settingsIncludeBackend = project.settingsIncludeBackend,
                settingsResponsive = project.settingsResponsive,
                settingsDarkTheme = project.settingsDarkTheme,
                publishStatus = PublishStatus.DRAFT.name,
                createdAtMillis = project.createdAtMillis,
                updatedAtMillis = now
            )

            val fileEntities = sanitizedFiles.mapIndexed { idx, fileSpec ->
                LocalProjectFileEntity(
                    id = "${project.id}_v${newVersion}_file_$idx",
                    projectId = project.id,
                    path = fileSpec.path.take(200).ifBlank { "file_$idx.txt" },
                    language = fileSpec.language.take(40).ifBlank { "text" },
                    content = fileSpec.content.take(300000),
                    createdAtMillis = now,
                    updatedAtMillis = now
                )
            }

            val historyEntity = LocalPromptHistoryEntity(
                id = UUID.randomUUID().toString(),
                projectId = project.id,
                projectName = sanitizedName,
                prompt = sanitizedPrompt,
                actionType = actionType.name,
                imageCount = imageCount.coerceIn(0, 10).toLong(),
                summary = sanitizedSummary,
                version = newVersion,
                createdAtMillis = now
            )

            dao.saveProjectBundle(updatedProject, fileEntities, historyEntity)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "applyAiUpdateToProject failed", e)
            Result.failure(e)
        }
    }

    suspend fun updateProjectSettings(
        projectId: String,
        name: String,
        appType: AppType,
        settings: ProjectSettingsDraft
    ): Result<Unit> {
        return try {
            require(projectId.isNotBlank())
            val sanitizedName = name.trim().ifBlank { "Untitled App" }.take(120)
            dao.updateProjectSettings(
                projectId = projectId,
                name = sanitizedName,
                appType = appType.name,
                includeBackend = settings.includeBackend,
                responsive = settings.responsive,
                darkTheme = settings.darkTheme,
                updatedAtMillis = System.currentTimeMillis()
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "updateProjectSettings failed", e)
            Result.failure(e)
        }
    }

    suspend fun publishProject(projectId: String): Result<Unit> {
        return try {
            require(projectId.isNotBlank())
            dao.updatePublishStatus(
                projectId = projectId,
                publishStatus = PublishStatus.PUBLISHED.name,
                updatedAtMillis = System.currentTimeMillis()
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "publishProject failed", e)
            Result.failure(e)
        }
    }

    suspend fun deleteProject(projectId: String): Result<Unit> {
        return try {
            require(projectId.isNotBlank())
            dao.deleteProjectById(projectId)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "deleteProject failed", e)
            Result.failure(e)
        }
    }

    private companion object {
        const val TAG = "ProjectRepository"
    }
}

private fun LocalProjectEntity.toDomain(): GeneratedProject = GeneratedProject(
    id = id,
    name = name,
    summary = summary,
    appType = appType,
    promptLanguage = promptLanguage,
    lastPrompt = lastPrompt,
    techStack = techStack,
    primaryColorHex = primaryColorHex,
    accentColorHex = accentColorHex,
    deploymentGuide = deploymentGuide,
    previewHtml = previewHtml,
    fileCount = fileCount,
    version = version,
    settingsIncludeBackend = settingsIncludeBackend,
    settingsResponsive = settingsResponsive,
    settingsDarkTheme = settingsDarkTheme,
    publishStatus = publishStatus,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis
)

private fun LocalProjectFileEntity.toDomain(): ProjectFile = ProjectFile(
    id = id,
    projectId = projectId,
    path = path,
    language = language,
    content = content,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis
)

private fun LocalPromptHistoryEntity.toDomain(): PromptHistoryEntry = PromptHistoryEntry(
    id = id,
    projectId = projectId,
    projectName = projectName,
    prompt = prompt,
    actionType = actionType,
    imageCount = imageCount,
    summary = summary,
    version = version,
    createdAtMillis = createdAtMillis
)
