package com.example.data

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.model.GeneratedProject
import com.example.model.ProjectFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ExportManager {

    fun safeFileSlug(name: String): String {
        val slug = name.lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
        return slug.ifBlank { "prompt2app-project" }
    }

    suspend fun buildWebsiteZipBytes(
        project: GeneratedProject,
        files: List<ProjectFile>
    ): ByteArray = withContext(Dispatchers.IO) {
        val out = ByteArrayOutputStream()
        val seenPaths = mutableSetOf<String>()

        ZipOutputStream(out).use { zip ->
            val exportFiles = if (files.isNotEmpty()) {
                files.map { it.path.trimStart('/') to it.content }
            } else {
                listOf("index.html" to project.previewHtml)
            }

            exportFiles.forEach { (rawPath, content) ->
                val cleanPath = rawPath.ifBlank { "index.html" }
                if (seenPaths.add(cleanPath)) {
                    zip.putNextEntry(ZipEntry(cleanPath))
                    zip.write(content.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                }
            }

            if (seenPaths.add("manifest.webmanifest")) {
                val manifest = """
                    {
                      "name": "${project.name.replace("\"", "")}",
                      "short_name": "${project.name.take(12).replace("\"", "")}",
                      "start_url": "./index.html",
                      "display": "standalone",
                      "background_color": "#060814",
                      "theme_color": "${project.primaryColorHex}"
                    }
                """.trimIndent()
                zip.putNextEntry(ZipEntry("manifest.webmanifest"))
                zip.write(manifest.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }

            if (seenPaths.add("DEPLOYMENT_GUIDE.md")) {
                zip.putNextEntry(ZipEntry("DEPLOYMENT_GUIDE.md"))
                zip.write(project.deploymentGuide.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
        out.toByteArray()
    }

    suspend fun buildAndroidWrapperZipBytes(
        project: GeneratedProject,
        files: List<ProjectFile>
    ): ByteArray = withContext(Dispatchers.IO) {
        val out = ByteArrayOutputStream()
        val appSlug = safeFileSlug(project.name).replace("-", "")
            .take(16)
            .ifBlank { "generatedapp" }
        val packageName = "com.prompt2app.$appSlug"
        val escapedTitle = project.name.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "")

        ZipOutputStream(out).use { zip ->
            fun addEntry(path: String, content: String) {
                zip.putNextEntry(ZipEntry(path))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }

            addEntry(
                "settings.gradle.kts",
                """
                pluginManagement {
                    repositories { google(); mavenCentral(); gradlePluginPortal() }
                }
                dependencyResolutionManagement {
                    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                    repositories { google(); mavenCentral() }
                }
                rootProject.name = "$escapedTitle"
                include(":app")
                """.trimIndent()
            )

            addEntry(
                "build.gradle.kts",
                """
                plugins {
                    id("com.android.application") version "8.7.2" apply false
                    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
                }
                """.trimIndent()
            )

            addEntry(
                "app/build.gradle.kts",
                """
                plugins {
                    id("com.android.application")
                    id("org.jetbrains.kotlin.android")
                }
                android {
                    namespace = "$packageName"
                    compileSdk = 35
                    defaultConfig {
                        applicationId = "$packageName"
                        minSdk = 24
                        targetSdk = 35
                        versionCode = ${project.version.toInt().coerceAtLeast(1)}
                        versionName = "1.${project.version}"
                    }
                    compileOptions {
                        sourceCompatibility = JavaVersion.VERSION_17
                        targetCompatibility = JavaVersion.VERSION_17
                    }
                    kotlinOptions { jvmTarget = "17" }
                }
                dependencies {
                    implementation("androidx.core:core-ktx:1.15.0")
                    implementation("androidx.appcompat:appcompat:1.7.0")
                }
                """.trimIndent()
            )

            addEntry(
                "app/src/main/AndroidManifest.xml",
                """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                    <uses-permission android:name="android.permission.INTERNET" />
                    <application
                        android:allowBackup="true"
                        android:label="$escapedTitle"
                        android:theme="@style/Theme.AppCompat.DayNight.NoActionBar">
                        <activity
                            android:name=".MainActivity"
                            android:exported="true">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
                """.trimIndent()
            )

            addEntry(
                "app/src/main/java/${packageName.replace('.', '/')}/MainActivity.kt",
                """
                package $packageName

                import android.annotation.SuppressLint
                import android.os.Bundle
                import android.webkit.WebChromeClient
                import android.webkit.WebView
                import android.webkit.WebViewClient
                import androidx.activity.OnBackPressedCallback
                import androidx.appcompat.app.AppCompatActivity

                class MainActivity : AppCompatActivity() {
                    private lateinit var webView: WebView

                    @SuppressLint("SetJavaScriptEnabled")
                    override fun onCreate(savedInstanceState: Bundle?) {
                        super.onCreate(savedInstanceState)
                        webView = WebView(this).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.databaseEnabled = true
                            webViewClient = WebViewClient()
                            webChromeClient = WebChromeClient()
                            loadUrl("file:///android_asset/www/index.html")
                        }
                        setContentView(webView)
                        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                            override fun handleOnBackPressed() {
                                if (webView.canGoBack()) webView.goBack() else finish()
                            }
                        })
                    }
                }
                """.trimIndent()
            )

            addEntry("app/src/main/assets/www/index.html", project.previewHtml)
            files.filter { !it.path.equals("index.html", ignoreCase = true) }.forEach { file ->
                val clean = file.path.trimStart('/')
                addEntry("app/src/main/assets/www/$clean", file.content)
            }

            addEntry(
                ".github/workflows/build-apk.yml",
                """
                name: Build Android APK
                on:
                  push:
                    branches: [ main, master ]
                  workflow_dispatch:
                jobs:
                  build:
                    runs-on: ubuntu-latest
                    steps:
                      - uses: actions/checkout@v4
                      - name: Set up JDK 17
                        uses: actions/setup-java@v4
                        with:
                          java-version: '17'
                          distribution: 'temurin'
                      - name: Setup Gradle
                        uses: gradle/actions/setup-gradle@v4
                      - name: Build Debug APK
                        run: gradle assembleDebug
                      - name: Upload APK Download Artifact
                        uses: actions/upload-artifact@v4
                        with:
                          name: ${safeFileSlug(project.name)}-apk
                          path: app/build/outputs/apk/debug/app-debug.apk
                """.trimIndent()
            )

            addEntry(
                "BUILD_APK_README.md",
                """
                # $escapedTitle — Android APK Wrapper Project
                
                ## Option 1: Free Cloud APK Download Link (GitHub Actions)
                1. Push this unzipped project to a free GitHub repository.
                2. GitHub Actions automatically runs `.github/workflows/build-apk.yml`.
                3. Download your ready-to-install `.apk` directly from the Actions Artifacts or Releases tab.
                
                ## Option 2: Local Build in Android Studio (Free)
                1. Open this unzipped folder in **Android Studio**.
                2. Wait for Gradle Sync to finish.
                3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)** (or run `./gradlew assembleDebug`).
                4. Find your APK at `app/build/outputs/apk/debug/app-debug.apk`.
                """.trimIndent()
            )
        }
        out.toByteArray()
    }

    fun buildStandaloneHtmlBytes(project: GeneratedProject): ByteArray {
        return project.previewHtml.toByteArray(Charsets.UTF_8)
    }

    suspend fun writeBytesToUri(context: Context, uri: Uri, bytes: ByteArray): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(bytes)
                    stream.flush()
                } ?: error("Unable to open destination file.")
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun createShareableFileUri(
        context: Context,
        fileName: String,
        bytes: ByteArray
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val outFile = File(exportDir, fileName)
            outFile.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outFile
            )
            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createShareableZipUri(
        context: Context,
        fileName: String,
        bytes: ByteArray
    ): Result<Uri> = createShareableFileUri(context, fileName, bytes)
}
