package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.example.model.ReferenceImageAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.max

object ImageAttachmentHelper {
    private val supportedMimeTypes = setOf(
        "image/png",
        "image/jpeg",
        "image/jpg",
        "image/webp"
    )

    private val supportedExtensions = setOf("png", "jpg", "jpeg", "webp")

    fun inspectImageUri(context: Context, uri: Uri): ReferenceImageAttachment? {
        val resolver = context.contentResolver
        val rawMime = resolver.getType(uri)?.lowercase()
        var displayName = "reference_image"
        var sizeBytes = 0L

        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) {
                        displayName = cursor.getString(nameIdx) ?: displayName
                    }
                    if (sizeIdx >= 0) {
                        sizeBytes = cursor.getLong(sizeIdx)
                    }
                }
            }

        val extension = displayName.substringAfterLast('.', "").lowercase()
            .ifBlank { MimeTypeMap.getFileExtensionFromUrl(uri.toString()).lowercase() }

        val resolvedMime = when {
            rawMime in supportedMimeTypes -> rawMime!!
            extension == "png" -> "image/png"
            extension == "webp" -> "image/webp"
            extension in setOf("jpg", "jpeg") -> "image/jpeg"
            else -> return null
        }

        if (extension.isNotBlank() && extension !in supportedExtensions && rawMime !in supportedMimeTypes) {
            return null
        }

        return ReferenceImageAttachment(
            id = UUID.randomUUID().toString(),
            uri = uri,
            mimeType = resolvedMime,
            displayName = displayName,
            sizeBytes = sizeBytes
        )
    }

    suspend fun decodeForGemini(
        context: Context,
        attachments: List<ReferenceImageAttachment>,
        maxDimensionPx: Int = 1024
    ): List<Bitmap> = withContext(Dispatchers.IO) {
        attachments.mapNotNull { attachment ->
            try {
                val boundsOptions = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                context.contentResolver.openInputStream(attachment.uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, boundsOptions)
                }

                val maxSide = max(boundsOptions.outWidth, boundsOptions.outHeight)
                var sampleSize = 1
                while (maxSide / sampleSize > maxDimensionPx * 2) {
                    sampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }

                val decoded = context.contentResolver.openInputStream(attachment.uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, decodeOptions)
                } ?: return@mapNotNull null

                val currentMax = max(decoded.width, decoded.height)
                if (currentMax > maxDimensionPx && currentMax > 0) {
                    val scale = maxDimensionPx.toFloat() / currentMax.toFloat()
                    val targetW = (decoded.width * scale).toInt().coerceAtLeast(1)
                    val targetH = (decoded.height * scale).toInt().coerceAtLeast(1)
                    val scaled = Bitmap.createScaledBitmap(decoded, targetW, targetH, true)
                    if (scaled !== decoded) decoded.recycle()
                    scaled
                } else {
                    decoded
                }
            } catch (_: Exception) {
                null
            }
        }
    }
}
