package com.example.data

import android.graphics.Bitmap
import android.util.Log
import com.example.model.AiGenerationResult
import com.example.model.AppType
import com.example.model.GeneratedFileSpec
import com.example.model.GeneratedProject
import com.example.model.ProjectFile
import com.example.model.ProjectSettingsDraft
import com.example.model.PromptLanguage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

class AiGeneratorRepository {

    private val generationSchema = Schema.obj(
        properties = mapOf(
            "projectName" to Schema.string(description = "Short professional project title"),
            "summary" to Schema.string(description = "Concise explanation of implemented features, UI structure, and design fidelity"),
            "techStack" to Schema.array(
                items = Schema.string(),
                description = "Technologies and open-source libraries used"
            ),
            "primaryColorHex" to Schema.string(description = "Hex color string like #8B5CF6"),
            "accentColorHex" to Schema.string(description = "Hex accent color string like #38BDF8"),
            "deploymentGuide" to Schema.string(description = "Step-by-step free hosting and Android APK export instructions"),
            "files" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "path" to Schema.string(description = "Relative file path e.g. index.html, styles.css, app.js, server/server.js, README.md"),
                        "language" to Schema.string(description = "File language e.g. html, css, javascript, sql, markdown, json"),
                        "content" to Schema.string(description = "Complete production-ready source file content")
                    )
                ),
                description = "Complete list of generated project files"
            ),
            "previewHtml" to Schema.string(
                description = "Single self-contained runnable HTML5 document combining HTML, CSS, and interactive JS so it executes immediately inside a WebView without external local file dependencies"
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.4f
                responseMimeType = "application/json"
                responseSchema = generationSchema
            }
        )
    }

    suspend fun generateProject(
        prompt: String,
        appType: AppType,
        language: PromptLanguage,
        settings: ProjectSettingsDraft,
        referenceBitmaps: List<Bitmap>
    ): AiGenerationResult {
        val systemInstructions = buildGenerationPrompt(
            userPrompt = prompt,
            appType = appType,
            language = language,
            settings = settings,
            imageCount = referenceBitmaps.size
        )
        return executeMultimodalGeneration(systemInstructions, referenceBitmaps)
    }

    suspend fun editExistingProject(
        currentProject: GeneratedProject,
        existingFiles: List<ProjectFile>,
        editInstruction: String,
        referenceBitmaps: List<Bitmap>
    ): AiGenerationResult {
        val systemInstructions = buildEditPrompt(
            currentProject = currentProject,
            existingFiles = existingFiles,
            editInstruction = editInstruction,
            imageCount = referenceBitmaps.size
        )
        return executeMultimodalGeneration(systemInstructions, referenceBitmaps)
    }

    private suspend fun executeMultimodalGeneration(
        instructionPrompt: String,
        referenceBitmaps: List<Bitmap>
    ): AiGenerationResult {
        try {
            val response = withTimeout(60_000L) {
                model.generateContent(
                    content {
                        referenceBitmaps.forEach { bitmap ->
                            image(bitmap)
                        }
                        text(instructionPrompt)
                    }
                )
            }
            val rawJson = response.text
                ?: throw IllegalStateException("AI model returned an empty response.")
            return parseAiResponse(rawJson)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini generation timed out after 60s", e)
            throw IllegalStateException("Generation timed out after 60 seconds. Try simplifying the prompt or attaching fewer images.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini generation failed", e)
            throw IllegalStateException(e.localizedMessage ?: "Failed to generate project with AI.")
        }
    }

    private fun parseAiResponse(rawJson: String): AiGenerationResult {
        val root = JSONObject(rawJson)
        val projectName = root.optString("projectName", "Generated App").ifBlank { "Generated App" }
        val summary = root.optString("summary", "Complete responsive application generated by Prompt2App AI.")
        val primaryColorHex = root.optString("primaryColorHex", "#8B5CF6").ifBlank { "#8B5CF6" }
        val accentColorHex = root.optString("accentColorHex", "#38BDF8").ifBlank { "#38BDF8" }
        val deploymentGuide = root.optString(
            "deploymentGuide",
            defaultDeploymentGuide(projectName)
        )

        val techStackArray = root.optJSONArray("techStack")
        val techStack = mutableListOf<String>()
        if (techStackArray != null) {
            for (i in 0 until techStackArray.length()) {
                val item = techStackArray.optString(i).trim()
                if (item.isNotBlank()) techStack.add(item)
            }
        }
        if (techStack.isEmpty()) {
            techStack.addAll(listOf("HTML5", "CSS3", "JavaScript"))
        }

        val filesArray = root.optJSONArray("files")
        val files = mutableListOf<GeneratedFileSpec>()
        if (filesArray != null) {
            for (i in 0 until filesArray.length()) {
                val fileObj = filesArray.optJSONObject(i) ?: continue
                val path = fileObj.optString("path").trim()
                val lang = fileObj.optString("language", "text").trim().ifBlank { "text" }
                val content = fileObj.optString("content", "")
                if (path.isNotBlank() && content.isNotBlank()) {
                    files.add(GeneratedFileSpec(path = path, language = lang, content = content))
                }
            }
        }

        var previewHtml = root.optString("previewHtml", "").trim()
        if (previewHtml.isBlank()) {
            previewHtml = assemblePreviewHtmlFromFiles(files, projectName)
        }

        if (files.none { it.path.equals("index.html", ignoreCase = true) } && previewHtml.isNotBlank()) {
            files.add(0, GeneratedFileSpec("index.html", "html", previewHtml))
        }

        return AiGenerationResult(
            projectName = projectName,
            summary = summary,
            techStack = techStack.take(15),
            primaryColorHex = primaryColorHex,
            accentColorHex = accentColorHex,
            deploymentGuide = deploymentGuide,
            previewHtml = previewHtml,
            files = files
        )
    }

    private fun assemblePreviewHtmlFromFiles(
        files: List<GeneratedFileSpec>,
        fallbackTitle: String
    ): String {
        val html = files.firstOrNull { it.path.endsWith("index.html", ignoreCase = true) }?.content
        val css = files.firstOrNull { it.path.endsWith(".css", ignoreCase = true) }?.content.orEmpty()
        val js = files.firstOrNull { it.path.endsWith(".js", ignoreCase = true) && !it.path.contains("server") }?.content.orEmpty()

        if (html.isNullOrBlank()) {
            return """
                <!DOCTYPE html>
                <html lang="en">
                <head>
                  <meta charset="UTF-8" />
                  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                  <title>$fallbackTitle</title>
                  <style>$css</style>
                </head>
                <body>
                  <main id="app"><h1>$fallbackTitle</h1></main>
                  <script>$js</script>
                </body>
                </html>
            """.trimIndent()
        }

        var combined = html
        if (css.isNotBlank() && !combined.contains(css.take(40))) {
            combined = combined.replace("</head>", "<style>\n$css\n</style>\n</head>", ignoreCase = true)
        }
        if (js.isNotBlank() && !combined.contains(js.take(40))) {
            combined = combined.replace("</body>", "<script>\n$js\n</script>\n</body>", ignoreCase = true)
        }
        return combined
    }

    private fun buildGenerationPrompt(
        userPrompt: String,
        appType: AppType,
        language: PromptLanguage,
        settings: ProjectSettingsDraft,
        imageCount: Int
    ): String {
        val langDirective = when (language) {
            PromptLanguage.AUTO -> "Understand the user's prompt whether written in English, Hindi (Devanagari), or Hinglish. Write UI text in the language implied by the prompt."
            PromptLanguage.EN -> "Write all visible UI copy, labels, and navigation in clean English."
            PromptLanguage.HI -> "Write visible UI copy naturally in Hindi (Devanagari) or clear Hinglish matching the user's request, while keeping code identifiers in English."
        }

        val imageDirective = if (imageCount > 0) {
            "CRITICAL: $imageCount reference image(s) are attached. Carefully inspect their layout hierarchy, visual style, color palette, typography, card geometry, navigation structure, and components, and reproduce the visual design and features as closely as possible."
        } else {
            "Create an original, cohesive, high-craft visual design tailored to the user's domain."
        }

        val backendDirective = if (settings.includeBackend) {
            "Include free open-source backend/database files in the `files` array (e.g., `backend/server.js` with Express + SQLite or `backend/schema.sql`, plus `README.md`), while making `previewHtml` work 100% interactively on the client via localStorage/IndexedDB persistence so the user can test every CRUD/form/auth flow live."
        } else {
            "If the prompt asks for persistence, login, cart, tasks, or data storage, implement real working client-side persistence via localStorage/IndexedDB inside `app.js` and `previewHtml`, and include backend/schema starter files in `files` when needed."
        }

        return """
            You are Prompt2App AI, a senior full-stack software architect and UI/UX engineer.
            Build a COMPLETE, WORKING, INTERACTIVE ${appType.label} (${appType.subtitle}) based on the user's prompt and reference images.
            
            User Prompt:
            "$userPrompt"
            
            Requirements:
            1. $imageDirective
            2. $langDirective
            3. $backendDirective
            4. NEVER generate a static mockup or placeholder-only page. Every button, tab, navigation link, search bar, filter, modal, form validation, state update, and interactive workflow MUST genuinely work in JavaScript.
            5. Responsiveness: ${if (settings.responsive) "Must adapt cleanly across Mobile (390px), Tablet (768px), and Desktop (1280px) viewports with proper viewport meta tag and responsive CSS Grid/Flexbox." else "Clean structured layout."}
            6. Theme preference: ${if (settings.darkTheme) "Prefer dark futuristic/modern aesthetic unless reference images clearly show a light theme (always honor reference images first)." else "Honor the light/brand aesthetic requested or shown in reference images."}
            7. Use 100% free and open-source technologies only (vanilla HTML5, CSS3, ES6+ JavaScript, inline SVG icons, optional free open-source CDNs or self-contained CSS). Never rely on paid APIs or broken external image URLs (use clean CSS gradients, inline SVGs, or Canvas graphics for visuals so nothing renders as a broken image).
            8. Output separate production files in `files` (`index.html`, `styles.css`, `app.js`, plus `manifest.webmanifest`, `README.md`, and backend files if applicable) AND provide `previewHtml` as a complete single-file HTML5 bundle with CSS in `<style>` and JS in `<script>` so it runs immediately offline inside Android WebView.
            9. Include accurate `deploymentGuide` covering free deployment (Netlify Drop, Cloudflare Pages, GitHub Pages) and Android APK export workflow.
        """.trimIndent()
    }

    private fun buildEditPrompt(
        currentProject: GeneratedProject,
        existingFiles: List<ProjectFile>,
        editInstruction: String,
        imageCount: Int
    ): String {
        val filesContext = existingFiles
            .filter { it.path != "README.md" }
            .take(8)
            .joinToString("\n\n") { file ->
                "--- FILE: ${file.path} (${file.language}) ---\n${file.content.take(18000)}"
            }

        val currentSource = filesContext.ifBlank {
            "--- CURRENT PREVIEW HTML ---\n${currentProject.previewHtml.take(28000)}"
        }

        return """
            You are Prompt2App AI modifying an EXISTING working project ("${currentProject.name}").
            Do NOT unnecessarily discard working features, layout structure, or existing data logic unless the user's edit instruction asks to replace them.
            Apply the requested changes cleanly across the existing files and `previewHtml`.
            
            Existing Project Summary: ${currentProject.summary}
            Previous Prompt: ${currentProject.lastPrompt}
            ${if (imageCount > 0) "Note: $imageCount new reference image(s) were attached for this edit—incorporate their design/content." else ""}
            
            New Edit Instruction (may be in English, Hindi, or Hinglish):
            "$editInstruction"
            
            Existing Codebase:
            $currentSource
            
            Return the updated complete `files` array and fully runnable `previewHtml` with all existing working features preserved plus the requested modifications. Ensure zero JS syntax errors and full responsiveness across Mobile, Tablet, and Desktop.
        """.trimIndent()
    }

    private fun defaultDeploymentGuide(projectName: String): String = """
        Free Deployment Guide for $projectName:
        1. Export the Website ZIP from Code & Export.
        2. Unzip the folder — `index.html`, `styles.css`, and `app.js` are ready for static hosting with zero build step.
        3. Free Hosting Options:
           • Cloudflare Pages / Netlify Drop: Drag and drop the unzipped folder for instant free HTTPS hosting.
           • GitHub Pages: Push files to a GitHub repo and enable Pages from the main branch.
        4. Android APK Export Workflow:
           • Download the Android Wrapper ZIP from the Export tab, open it in Android Studio (or run `./gradlew assembleDebug`), and build your installable APK locally for free.
    """.trimIndent()

    private companion object {
        const val TAG = "AiGeneratorRepo"
    }
}
