package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray

@Entity(tableName = "projects")
data class LocalProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val summary: String,
    val appType: String,
    val promptLanguage: String,
    val lastPrompt: String,
    val techStack: List<String>,
    val primaryColorHex: String,
    val accentColorHex: String,
    val deploymentGuide: String,
    val previewHtml: String,
    val fileCount: Long,
    val version: Long,
    val settingsIncludeBackend: Boolean,
    val settingsResponsive: Boolean,
    val settingsDarkTheme: Boolean,
    val publishStatus: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(
    tableName = "project_files",
    foreignKeys = [
        ForeignKey(
            entity = LocalProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class LocalProjectFileEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val path: String,
    val language: String,
    val content: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(tableName = "prompt_history")
data class LocalPromptHistoryEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val projectName: String,
    val prompt: String,
    val actionType: String,
    val imageCount: Long,
    val summary: String,
    val version: Long,
    val createdAtMillis: Long
)

class RoomConverters {
    @TypeConverter
    fun fromStringList(value: List<String>): String {
        val array = JSONArray()
        value.forEach { array.put(it) }
        return array.toString()
    }

    @TypeConverter
    fun toStringList(raw: String): List<String> {
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { idx ->
                array.optString(idx).takeIf { it.isNotBlank() }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAtMillis DESC")
    fun observeProjects(): Flow<List<LocalProjectEntity>>

    @Query("SELECT * FROM project_files WHERE projectId = :projectId ORDER BY path ASC")
    fun observeProjectFiles(projectId: String): Flow<List<LocalProjectFileEntity>>

    @Query("SELECT * FROM prompt_history ORDER BY createdAtMillis DESC LIMIT 50")
    fun observePromptHistory(): Flow<List<LocalPromptHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(project: LocalProjectEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFiles(files: List<LocalProjectFileEntity>)

    @Query("DELETE FROM project_files WHERE projectId = :projectId")
    suspend fun deleteFilesForProject(projectId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromptHistory(entry: LocalPromptHistoryEntity)

    @Query(
        """
        UPDATE projects
        SET name = :name,
            appType = :appType,
            settingsIncludeBackend = :includeBackend,
            settingsResponsive = :responsive,
            settingsDarkTheme = :darkTheme,
            updatedAtMillis = :updatedAtMillis
        WHERE id = :projectId
        """
    )
    suspend fun updateProjectSettings(
        projectId: String,
        name: String,
        appType: String,
        includeBackend: Boolean,
        responsive: Boolean,
        darkTheme: Boolean,
        updatedAtMillis: Long
    )

    @Query(
        """
        UPDATE projects
        SET publishStatus = :publishStatus,
            updatedAtMillis = :updatedAtMillis
        WHERE id = :projectId
        """
    )
    suspend fun updatePublishStatus(
        projectId: String,
        publishStatus: String,
        updatedAtMillis: Long
    )

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun deleteProjectById(projectId: String)

    @Transaction
    suspend fun saveProjectBundle(
        project: LocalProjectEntity,
        files: List<LocalProjectFileEntity>,
        historyEntry: LocalPromptHistoryEntity
    ) {
        upsertProject(project)
        deleteFilesForProject(project.id)
        if (files.isNotEmpty()) {
            insertFiles(files)
        }
        insertPromptHistory(historyEntry)
    }
}

@Database(
    entities = [
        LocalProjectEntity::class,
        LocalProjectFileEntity::class,
        LocalPromptHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(RoomConverters::class)
abstract class Prompt2AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile
        private var INSTANCE: Prompt2AppDatabase? = null

        fun getInstance(context: Context): Prompt2AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    Prompt2AppDatabase::class.java,
                    "prompt2app_local.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
