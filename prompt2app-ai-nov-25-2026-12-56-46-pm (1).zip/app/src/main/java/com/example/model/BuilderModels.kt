package com.example.model

import android.net.Uri

enum class AppType(val label: String, val subtitle: String) {
    WEBSITE("Website", "Responsive multi-section site"),
    WEB_APP("Web App", "Interactive SPA with state & forms"),
    ANDROID_PWA("App + PWA", "Mobile-first PWA & Android wrapper");

    companion object {
        fun fromRaw(raw: String?): AppType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: WEB_APP
    }
}

enum class PromptLanguage(val label: String, val code: String) {
    AUTO("Auto (EN / हिंदी)", "auto"),
    EN("English", "en-US"),
    HI("हिंदी / Hinglish", "hi-IN");

    companion object {
        fun fromRaw(raw: String?): PromptLanguage =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: AUTO
    }
}

enum class ActionType(val label: String) {
    GENERATE("Generated"),
    AI_EDIT("AI Edit"),
    REGENERATE("Regenerated");

    companion object {
        fun fromRaw(raw: String?): ActionType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: GENERATE
    }
}

enum class PreviewDevice(val label: String, val widthPx: Int) {
    MOBILE("Mobile", 390),
    TABLET("Tablet", 768),
    DESKTOP("Desktop", 1280)
}

enum class BuilderTab(val route: String, val label: String) {
    STUDIO("studio", "Builder"),
    PREVIEW("preview", "Preview"),
    CODE("code", "Code & Export"),
    PROJECTS("projects", "Projects")
}

enum class PublishStatus {
    DRAFT,
    PUBLISHED;

    companion object {
        fun fromRaw(raw: String?): PublishStatus =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: DRAFT
    }
}

enum class CopilotReviewPhase {
    NONE,
    ASKING_REVIEW,
    PUBLISHED
}

data class AgentPipelineStep(
    val title: String,
    val completed: Boolean = false,
    val active: Boolean = false
)

data class GeneratedProject(
    val id: String = "",
    val name: String = "",
    val summary: String = "",
    val appType: String = AppType.WEB_APP.name,
    val promptLanguage: String = PromptLanguage.AUTO.name,
    val lastPrompt: String = "",
    val techStack: List<String> = emptyList(),
    val primaryColorHex: String = "#8B5CF6",
    val accentColorHex: String = "#38BDF8",
    val deploymentGuide: String = "",
    val previewHtml: String = "",
    val fileCount: Long = 0L,
    val version: Long = 1L,
    val settingsIncludeBackend: Boolean = false,
    val settingsResponsive: Boolean = true,
    val settingsDarkTheme: Boolean = true,
    val publishStatus: String = PublishStatus.DRAFT.name,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    fun resolvedAppType(): AppType = AppType.fromRaw(appType)
    fun resolvedLanguage(): PromptLanguage = PromptLanguage.fromRaw(promptLanguage)
    fun isPublished(): Boolean = PublishStatus.fromRaw(publishStatus) == PublishStatus.PUBLISHED
}

data class ProjectFile(
    val id: String = "",
    val projectId: String = "",
    val path: String = "",
    val language: String = "text",
    val content: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)

data class PromptHistoryEntry(
    val id: String = "",
    val projectId: String = "",
    val projectName: String = "",
    val prompt: String = "",
    val actionType: String = ActionType.GENERATE.name,
    val imageCount: Long = 0L,
    val summary: String = "",
    val version: Long = 1L,
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    fun resolvedActionType(): ActionType = ActionType.fromRaw(actionType)
}

data class ReferenceImageAttachment(
    val id: String,
    val uri: Uri,
    val mimeType: String,
    val displayName: String,
    val sizeBytes: Long
) {
    fun formatLabel(): String = when {
        mimeType.contains("png", ignoreCase = true) -> "PNG"
        mimeType.contains("webp", ignoreCase = true) -> "WEBP"
        else -> "JPG"
    }
}

data class ProjectSettingsDraft(
    val includeBackend: Boolean = false,
    val responsive: Boolean = true,
    val darkTheme: Boolean = true
)

data class GeneratedFileSpec(
    val path: String,
    val language: String,
    val content: String
)

data class AiGenerationResult(
    val projectName: String,
    val summary: String,
    val techStack: List<String>,
    val primaryColorHex: String,
    val accentColorHex: String,
    val deploymentGuide: String,
    val previewHtml: String,
    val files: List<GeneratedFileSpec>
)

data class ConsoleLogEntry(
    val level: String,
    val message: String,
    val lineNumber: Int,
    val sourceId: String
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface GenerationState {
    data object Idle : GenerationState
    data class InProgress(val stageLabel: String, val isEdit: Boolean = false) : GenerationState
    data class Completed(val projectId: String, val message: String) : GenerationState
    data class Failed(val message: String) : GenerationState
}
