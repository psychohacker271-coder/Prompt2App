package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.core.configureAppCheck
import com.example.data.AiGeneratorRepository
import com.example.data.ProjectRepository
import com.example.ui.Prompt2AppRoot
import com.example.ui.theme.Prompt2AppTheme
import com.example.viewmodel.BuilderViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent BEFORE UI or any Firebase AI calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            Prompt2AppTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val builderViewModel: BuilderViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                BuilderViewModel(
                    projectRepository = ProjectRepository(app),
                    aiRepository = AiGeneratorRepository()
                )
            }
        }
    )
    Prompt2AppRoot(viewModel = builderViewModel)
}
