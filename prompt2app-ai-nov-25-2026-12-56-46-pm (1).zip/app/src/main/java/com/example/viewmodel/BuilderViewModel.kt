package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AiGeneratorRepository
import com.example.data.ImageAttachmentHelper
import com.example.data.ProjectRepository
import com.example.model.ActionType
import com.example.model.AgentPipelineStep
import com.example.model.AppType
import com.example.model.ConsoleLogEntry
import com.example.model.CopilotReviewPhase
import com.example.model.GeneratedProject
import com.example.model.GenerationState
import com.example.model.PreviewDevice
import com.example.model.ProjectFile
import com.example.model.ProjectSettingsDraft
import com.example.model.PromptHistoryEntry
import com.example.model.PromptLanguage
import com.example.model.ReferenceImageAttachment
import com.example.model.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class BuilderViewModel(
    private val projectRepository: ProjectRepository,
    private val aiRepository: AiGeneratorRepository
) : ViewModel() {

    val projectsState: StateFlow<UiState<List<GeneratedProject>>> =
        projectRepository.observeProjects()
            .map<List<GeneratedProject>, UiState<List<GeneratedProject>>> { UiState.Success(it) }
            .catch { error ->
                if (error is CancellationException) throw error
                Log.w(TAG, "Error observing projects", error)
                emit(UiState.Error(error.localizedMessage ?: "Failed to load saved projects."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val promptHistoryState: StateFlow<UiState<List<PromptHistoryEntry>>> =
        projectRepository.observePromptHistory()
            .map<List<PromptHistoryEntry>, UiState<List<PromptHistoryEntry>>> { UiState.Success(it) }
            .catch { error ->
                if (error is CancellationException) throw error
                Log.w(TAG, "Error observing prompt history", error)
                emit(UiState.Error(error.localizedMessage ?: "Failed to load prompt history."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    private val _selectedProjectId = MutableStateFlow<String?>(null)

    val activeProject: StateFlow<GeneratedProject?> = combine(
        projectsState,
        _selectedProjectId
    ) { state, selectedId ->
        val list = (state as? UiState.Success)?.data.orEmpty()
        if (selectedId != null) {
            list.firstOrNull { it.id == selectedId } ?: list.firstOrNull()
        } else {
            list.firstOrNull()
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = null
    )

    val activeProjectFiles: StateFlow<List<ProjectFile>> = activeProject
        .flatMapLatest { project ->
            if (project == null || project.id.isBlank()) {
                flowOf(emptyList())
            } else {
                projectRepository.observeProjectFiles(project.id)
                    .catch { error ->
                        if (error is CancellationException) throw error
                        Log.w(TAG, "Error observing files", error)
                        emit(emptyList())
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    private val _promptText = MutableStateFlow("")
    val promptText: StateFlow<String> = _promptText.asStateFlow()

    private val _appType = MutableStateFlow(AppType.WEB_APP)
    val appType: StateFlow<AppType> = _appType.asStateFlow()

    private val _promptLanguage = MutableStateFlow(PromptLanguage.AUTO)
    val promptLanguage: StateFlow<PromptLanguage> = _promptLanguage.asStateFlow()

    private val _attachments = MutableStateFlow<List<ReferenceImageAttachment>>(emptyList())
    val attachments: StateFlow<List<ReferenceImageAttachment>> = _attachments.asStateFlow()

    private val _settingsDraft = MutableStateFlow(ProjectSettingsDraft())
    val settingsDraft: StateFlow<ProjectSettingsDraft> = _settingsDraft.asStateFlow()

    private val _generationState = MutableStateFlow<GenerationState>(GenerationState.Idle)
    val generationState: StateFlow<GenerationState> = _generationState.asStateFlow()

    private val _agentSteps = MutableStateFlow<List<AgentPipelineStep>>(emptyList())
    val agentSteps: StateFlow<List<AgentPipelineStep>> = _agentSteps.asStateFlow()

    private val _copilotPhase = MutableStateFlow(CopilotReviewPhase.NONE)
    val copilotPhase: StateFlow<CopilotReviewPhase> = _copilotPhase.asStateFlow()

    private val _previewDevice = MutableStateFlow(PreviewDevice.MOBILE)
    val previewDevice: StateFlow<PreviewDevice> = _previewDevice.asStateFlow()

    private val _aiEditInstruction = MutableStateFlow("")
    val aiEditInstruction: StateFlow<String> = _aiEditInstruction.asStateFlow()

    private val _consoleLogs = MutableStateFlow<List<ConsoleLogEntry>>(emptyList())
    val consoleLogs: StateFlow<List<ConsoleLogEntry>> = _consoleLogs.asStateFlow()

    private val _previewReloadNonce = MutableStateFlow(0)
    val previewReloadNonce: StateFlow<Int> = _previewReloadNonce.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun updatePromptText(text: String) {
        _promptText.value = text
    }

    fun appendVoiceTranscript(transcript: String) {
        val clean = transcript.trim()
        if (clean.isBlank()) return
        val current = _promptText.value.trim()
        _promptText.value = if (current.isEmpty()) clean else "$current $clean"
    }

    fun appendEditVoiceTranscript(transcript: String) {
        val clean = transcript.trim()
        if (clean.isBlank()) return
        val current = _aiEditInstruction.value.trim()
        _aiEditInstruction.value = if (current.isEmpty()) clean else "$current $clean"
    }

    fun updateAppType(type: AppType) {
        _appType.value = type
    }

    fun updatePromptLanguage(lang: PromptLanguage) {
        _promptLanguage.value = lang
    }

    fun updateSettingsDraft(settings: ProjectSettingsDraft) {
        _settingsDraft.value = settings
    }

    fun updatePreviewDevice(device: PreviewDevice) {
        _previewDevice.value = device
    }

    fun updateAiEditInstruction(text: String) {
        _aiEditInstruction.value = text
    }

    fun addConsoleLog(entry: ConsoleLogEntry) {
        _consoleLogs.value = (_consoleLogs.value + entry).takeLast(40)
    }

    fun clearConsoleLogs() {
        _consoleLogs.value = emptyList()
    }

    fun triggerPreviewReload() {
        clearConsoleLogs()
        _previewReloadNonce.value += 1
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun addImagesFromUris(context: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val current = _attachments.value.toMutableList()
        var rejectedCount = 0
        uris.forEach { uri ->
            if (current.size >= 5) return@forEach
            val inspected = ImageAttachmentHelper.inspectImageUri(context, uri)
            if (inspected != null) {
                if (current.none { it.uri == uri }) {
                    current.add(inspected)
                }
            } else {
                rejectedCount++
            }
        }
        _attachments.value = current
        if (rejectedCount > 0) {
            _toastMessage.value = "Only PNG, JPG, JPEG, and WEBP reference images are supported."
        }
    }

    fun removeAttachment(id: String) {
        _attachments.value = _attachments.value.filterNot { it.id == id }
    }

    fun selectProject(project: GeneratedProject) {
        _selectedProjectId.value = project.id
        _copilotPhase.value = if (project.isPublished()) {
            CopilotReviewPhase.PUBLISHED
        } else {
            CopilotReviewPhase.ASKING_REVIEW
        }
        clearConsoleLogs()
        _previewReloadNonce.value += 1
    }

    fun startNewProjectDraft() {
        _promptText.value = ""
        _attachments.value = emptyList()
        _generationState.value = GenerationState.Idle
        _agentSteps.value = emptyList()
    }

    private fun updateSteps(activeIndex: Int, isEdit: Boolean = false) {
        val labels = if (isEdit) {
            listOf(
                "Reading current codebase & instruction",
                "Applying targeted AI changes",
                "Verifying preview & saving revision"
            )
        } else {
            listOf(
                "Analyzing prompt & reference images",
                "Architecting UI, backend & database",
                "Writing working interactive code",
                "Saving workspace & launching preview"
            )
        }
        _agentSteps.value = labels.mapIndexed { index, title ->
            AgentPipelineStep(
                title = title,
                completed = index < activeIndex,
                active = index == activeIndex
            )
        }
    }

    fun generateNewProject(
        context: Context,
        onNavigateToPreview: () -> Unit
    ) {
        val prompt = _promptText.value.trim()
        val images = _attachments.value
        if (prompt.isBlank() && images.isEmpty()) {
            _toastMessage.value = "Enter a prompt (English or हिंदी) or attach a reference image."
            return
        }

        val effectivePrompt = prompt.ifBlank {
            "Analyze the attached reference image(s) and build a complete working application matching the exact design and layout."
        }

        viewModelScope.launch {
            try {
                updateSteps(activeIndex = 0)
                _generationState.value = GenerationState.InProgress(
                    stageLabel = if (images.isNotEmpty()) {
                        "Analyzing ${images.size} reference image(s) & prompt..."
                    } else {
                        "Analyzing your requirements automatically..."
                    }
                )

                val bitmaps = ImageAttachmentHelper.decodeForGemini(context, images)
                updateSteps(activeIndex = 1)
                _generationState.value = GenerationState.InProgress("Designing UI & building full interactive features...")

                updateSteps(activeIndex = 2)
                val result = aiRepository.generateProject(
                    prompt = effectivePrompt,
                    appType = _appType.value,
                    language = _promptLanguage.value,
                    settings = _settingsDraft.value,
                    referenceBitmaps = bitmaps
                )
                bitmaps.forEach { if (!it.isRecycled) it.recycle() }

                updateSteps(activeIndex = 3)
                _generationState.value = GenerationState.InProgress("Saving project & opening live review...")
                val saveResult = projectRepository.saveNewProject(
                    prompt = effectivePrompt,
                    appType = _appType.value,
                    language = _promptLanguage.value,
                    settings = _settingsDraft.value,
                    imageCount = images.size,
                    result = result
                )

                saveResult.fold(
                    onSuccess = { newId ->
                        _selectedProjectId.value = newId
                        _agentSteps.value = _agentSteps.value.map { it.copy(completed = true, active = false) }
                        _copilotPhase.value = CopilotReviewPhase.ASKING_REVIEW
                        clearConsoleLogs()
                        _previewReloadNonce.value += 1
                        _generationState.value = GenerationState.Completed(
                            projectId = newId,
                            message = "${result.projectName} is ready!"
                        )
                        onNavigateToPreview()
                    },
                    onFailure = { err ->
                        _generationState.value = GenerationState.Failed(
                            err.localizedMessage ?: "Generated code, but failed to save project locally."
                        )
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "generateNewProject failed", e)
                _generationState.value = GenerationState.Failed(
                    e.localizedMessage ?: "Generation failed. Please check your connection and try again."
                )
            }
        }
    }

    fun submitCopilotReply(context: Context, instructionOverride: String? = null) {
        val raw = (instructionOverride ?: _aiEditInstruction.value).trim()
        if (raw.isBlank()) {
            _toastMessage.value = "Type what to add/change, or tap 'Theek hai, Publish!'."
            return
        }
        if (instructionOverride == null && isPublishConfirmation(raw)) {
            _aiEditInstruction.value = ""
            publishActiveProject()
            return
        }
        applyAiEdit(context, raw)
    }

    private fun isPublishConfirmation(text: String): Boolean {
        val normalized = text.lowercase()
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
        val publishPhrases = setOf(
            "theek hai", "thik hai", "theek", "thik", "ok", "okay", "ok publish",
            "publish", "publish karo", "publish kar do", "publish kardo", "publish it",
            "done", "bas", "nahi", "no", "nothing", "nothing else", "looks good",
            "sab theek hai", "haan publish", "yes publish", "ready", "kardo"
        )
        return normalized in publishPhrases ||
            (normalized.startsWith("theek hai") && normalized.contains("publish")) ||
            normalized == "kuch nahi" || normalized == "aur kuch nahi"
    }

    fun publishActiveProject() {
        val project = activeProject.value ?: return
        viewModelScope.launch {
            val res = projectRepository.publishProject(project.id)
            res.fold(
                onSuccess = {
                    _copilotPhase.value = CopilotReviewPhase.PUBLISHED
                    _toastMessage.value = "${project.name} published! Ready to download ZIP, HTML & APK project."
                },
                onFailure = { e ->
                    _toastMessage.value = e.localizedMessage ?: "Failed to publish project."
                }
            )
        }
    }

    fun reopenReviewFromPublished() {
        _copilotPhase.value = CopilotReviewPhase.ASKING_REVIEW
    }

    fun applyAiEdit(
        context: Context,
        instructionOverride: String? = null
    ) {
        val project = activeProject.value
        if (project == null) {
            _toastMessage.value = "Generate or open a project first before editing."
            return
        }
        val instruction = (instructionOverride ?: _aiEditInstruction.value).trim()
        if (instruction.isBlank()) {
            _toastMessage.value = "Enter an AI edit instruction (e.g., Change colors or Add login)."
            return
        }

        viewModelScope.launch {
            try {
                updateSteps(activeIndex = 0, isEdit = true)
                _generationState.value = GenerationState.InProgress(
                    stageLabel = "Applying targeted AI edit to ${project.name}...",
                    isEdit = true
                )
                val bitmaps = ImageAttachmentHelper.decodeForGemini(context, _attachments.value)
                val currentFiles = activeProjectFiles.value

                updateSteps(activeIndex = 1, isEdit = true)
                val result = aiRepository.editExistingProject(
                    currentProject = project,
                    existingFiles = currentFiles,
                    editInstruction = instruction,
                    referenceBitmaps = bitmaps
                )
                bitmaps.forEach { if (!it.isRecycled) it.recycle() }

                updateSteps(activeIndex = 2, isEdit = true)
                val updateResult = projectRepository.applyAiUpdateToProject(
                    project = project,
                    instruction = instruction,
                    actionType = ActionType.AI_EDIT,
                    imageCount = _attachments.value.size,
                    result = result
                )

                updateResult.fold(
                    onSuccess = {
                        _aiEditInstruction.value = ""
                        _agentSteps.value = _agentSteps.value.map { it.copy(completed = true, active = false) }
                        _copilotPhase.value = CopilotReviewPhase.ASKING_REVIEW
                        clearConsoleLogs()
                        _previewReloadNonce.value += 1
                        _generationState.value = GenerationState.Completed(
                            projectId = project.id,
                            message = "Updated ${project.name} (v${project.version + 1})"
                        )
                        _toastMessage.value = "Updated to v${project.version + 1}! Ready for review or publish."
                    },
                    onFailure = { err ->
                        _generationState.value = GenerationState.Failed(
                            err.localizedMessage ?: "Failed to save AI edit."
                        )
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "applyAiEdit failed", e)
                _generationState.value = GenerationState.Failed(
                    e.localizedMessage ?: "AI edit failed. Please try again."
                )
            }
        }
    }

    fun regenerateActiveProject(context: Context) {
        val project = activeProject.value ?: return
        viewModelScope.launch {
            try {
                updateSteps(activeIndex = 1, isEdit = true)
                _generationState.value = GenerationState.InProgress(
                    stageLabel = "Regenerating ${project.name} from scratch...",
                    isEdit = true
                )
                val bitmaps = ImageAttachmentHelper.decodeForGemini(context, _attachments.value)

                val result = aiRepository.generateProject(
                    prompt = project.lastPrompt,
                    appType = project.resolvedAppType(),
                    language = project.resolvedLanguage(),
                    settings = ProjectSettingsDraft(
                        includeBackend = project.settingsIncludeBackend,
                        responsive = project.settingsResponsive,
                        darkTheme = project.settingsDarkTheme
                    ),
                    referenceBitmaps = bitmaps
                )
                bitmaps.forEach { if (!it.isRecycled) it.recycle() }

                updateSteps(activeIndex = 2, isEdit = true)
                val updateResult = projectRepository.applyAiUpdateToProject(
                    project = project,
                    instruction = project.lastPrompt,
                    actionType = ActionType.REGENERATE,
                    imageCount = _attachments.value.size,
                    result = result
                )

                updateResult.fold(
                    onSuccess = {
                        _copilotPhase.value = CopilotReviewPhase.ASKING_REVIEW
                        clearConsoleLogs()
                        _previewReloadNonce.value += 1
                        _generationState.value = GenerationState.Completed(
                            projectId = project.id,
                            message = "Regenerated ${project.name} (v${project.version + 1})"
                        )
                        _toastMessage.value = "Project regenerated (v${project.version + 1})"
                    },
                    onFailure = { err ->
                        _generationState.value = GenerationState.Failed(
                            err.localizedMessage ?: "Failed to save regenerated project."
                        )
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "regenerateActiveProject failed", e)
                _generationState.value = GenerationState.Failed(
                    e.localizedMessage ?: "Regeneration failed."
                )
            }
        }
    }

    fun updateActiveProjectSettings(
        projectId: String,
        name: String,
        appType: AppType,
        settings: ProjectSettingsDraft
    ) {
        viewModelScope.launch {
            val res = projectRepository.updateProjectSettings(
                projectId = projectId,
                name = name,
                appType = appType,
                settings = settings
            )
            res.fold(
                onSuccess = { _toastMessage.value = "Project settings saved." },
                onFailure = { e -> _toastMessage.value = e.localizedMessage ?: "Failed to save settings." }
            )
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            val res = projectRepository.deleteProject(projectId)
            res.fold(
                onSuccess = {
                    if (_selectedProjectId.value == projectId) {
                        _selectedProjectId.value = null
                    }
                    _toastMessage.value = "Project deleted."
                },
                onFailure = { e -> _toastMessage.value = e.localizedMessage ?: "Failed to delete project." }
            )
        }
    }

    private companion object {
        const val TAG = "BuilderViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
